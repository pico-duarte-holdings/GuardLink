/*
Copyright 2026 Pico Duarte Holdings LLC. All rights reserved.
This code, design, and associated assets may not be reproduced, distributed, or transmitted in any form or by any means without prior written permission.
*/
import React, { useState, useEffect, useRef } from 'react';
import { 
  Users, TrendingUp, Mail, Calendar, CheckCircle, Clock, Search, Filter,
  MoreVertical, ArrowLeft, LogOut, ShieldAlert, Download, Activity,
  CheckSquare, Square, Trash2, ChevronDown, LogIn, Loader2, History,
  Eye, X, UserPlus, Moon, Sun, Settings, Smartphone, MapPin, Instagram, 
  Facebook, Link as LinkIcon, Linkedin, Youtube, MessageSquare, Phone, Edit, Plus, Upload, QrCode, Forward, AlertTriangle
} from 'lucide-react';
import { 
  BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer,
  PieChart, Pie, Cell
} from 'recharts';
import { motion, AnimatePresence } from 'motion/react';
import { onSnapshot, collection, query, orderBy, updateDoc, doc, where, getDoc, setDoc, deleteDoc, addDoc } from 'firebase/firestore';
import { signInWithPopup, GoogleAuthProvider, onAuthStateChanged, signOut } from 'firebase/auth';
import { db, auth, handleFirestoreError, OperationType } from './firebase';
import { Lead, Subscription } from './types';
import { cn } from './lib/utils';
import { Bell } from 'lucide-react';

const LEAD_STATUSES = ['New', 'Contacted', 'Appointment', 'ASVAB', 'Physical', 'Waiver', 'Qualified', 'Enlisted'];
const CHART_COLORS = ['#FFD530', '#00f2ff', '#39ff14', '#a855f7', '#ff0055', '#ffffff'];
const PLATOONS = ['HQ', 'C1', 'C2', 'C3', 'C4']; 

export const RecruiterDashboard = ({ onBack }: { onBack: () => void }) => {
  const [isFirebaseAuthenticated, setIsFirebaseAuthenticated] = useState(false);
  const [userRole, setUserRole] = useState<'admin' | 'recruiter' | 'pending' | null>(null);
  const [userPlatoons, setUserPlatoons] = useState<string[]>(['HQ']);
  const [userSlug, setUserSlug] = useState<string | null>(null);
  const [isCommander, setIsCommander] = useState(false);
  const [error, setError] = useState('');
  
  // Data State
  const [leads, setLeads] = useState<Lead[]>([]);
  const [subscriptions, setSubscriptions] = useState<Subscription[]>([]);
  const [team, setTeam] = useState<any[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [activeTab, setActiveTab] = useState<'leads' | 'subscriptions' | 'team'>('leads');

  // Modals & Action State
  const [showLogoutConfirm, setShowLogoutConfirm] = useState(false);
  const [showProfileModal, setShowProfileModal] = useState(false);
  const [showCreateRecruiter, setShowCreateRecruiter] = useState(false);
  const [showAddLeadModal, setShowAddLeadModal] = useState(false);
  const [showCSVModal, setShowCSVModal] = useState(false);
  
  const [editingMember, setEditingMember] = useState<any | null>(null);
  const [editingLead, setEditingLead] = useState<Lead | null>(null);
  const [editingSub, setEditingSub] = useState<Subscription | null>(null);
  const [journeyLead, setJourneyLead] = useState<Lead | null>(null);
  
  const fileInputRef = useRef<HTMLInputElement>(null);
  const [csvAssignee, setCsvAssignee] = useState('');
  const [newNote, setNewNote] = useState('');

  const [profileData, setProfileData] = useState({
    rank: '', firstName: '', lastName: '', cellPhone: '', officePhone: '',
    officeExt: '', publicEmail: '', locationType: 'Armory', address1: '',
    address2: '', city: '', state: 'FL', zip: '', instagram: '', facebook: '',
    tiktok: '', linkedin: '', discord: '', youtube: '', linktree: '', 
    platoons: ['HQ'], 
    smsTemplate: 'Hey {{name}}, this is {{recruiter}} with the FLARNG. Are you still interested in leveling up your career?',
    emailTemplate: 'Hello {{name}},\n\nThank you for your interest in the Florida Army National Guard. Let me know when you have time for a quick call to discuss your options.\n\nRespectfully,\n{{recruiter}}'
  });

  // Filtering State
  const [searchQuery, setSearchQuery] = useState('');
  const [statusFilter, setStatusFilter] = useState('All');
  const [sourceFilter, setSourceFilter] = useState('All');
  const [mosFilter, setMosFilter] = useState('All');
  const [recruiterFilter, setRecruiterFilter] = useState('All');
  const [startDate, setStartDate] = useState('');
  const [endDate, setEndDate] = useState('');
  const [showFilters, setShowFilters] = useState(false);
  
  // Add Lead State
  const [newLeadData, setNewLeadData] = useState({
    firstName: '', lastName: '', phone: '', email: '', age: '', education: 'HS Graduate', interest: 'Enlisted', mos: 'TBD', source: 'Manual Entry'
  });

  // Form State
  const [createRecruiterEmail, setCreateRecruiterEmail] = useState('');
  const [createRecruiterName, setCreateRecruiterName] = useState('');
  const [createRecruiterRole, setCreateRecruiterRole] = useState('recruiter');
  const [createRecruiterSlug, setCreateRecruiterSlug] = useState('');
  const [createRecruiterPlatoons, setCreateRecruiterPlatoons] = useState<string[]>(['HQ']);

  const [selectedEmails, setSelectedEmails] = useState<Set<string>>(new Set());

  const [isDarkMode, setIsDarkMode] = useState(() => {
    const saved = localStorage.getItem('theme');
    return saved ? saved === 'dark' : true;
  });

  useEffect(() => {
    localStorage.setItem('theme', isDarkMode ? 'dark' : 'light');
    if (isDarkMode) {
      document.documentElement.classList.remove('light-theme');
    } else {
      document.documentElement.classList.add('light-theme');
    }
  }, [isDarkMode]);

  // Firebase Auth Listener
  useEffect(() => {
    const unsubscribe = onAuthStateChanged(auth, async (user) => {
      setIsFirebaseAuthenticated(!!user);
      if (user) {
        try {
          const isMaster = user.email?.toLowerCase() === 'angellantigua98@gmail.com';
          setIsCommander(isMaster);
          
          const userDoc = await getDoc(doc(db, 'users', user.uid));
          
          if (userDoc.exists()) {
            const data = userDoc.data();
            setUserRole(data.role || (isMaster ? 'admin' : 'recruiter'));
            setUserSlug(data.slug || null);
            
            // Handle Legacy Platoon String -> Array migration
            const loadedPlatoons = data.platoons || (data.platoon ? [data.platoon] : ['HQ']);
            setUserPlatoons(loadedPlatoons);
            
            setProfileData({
              rank: data.rank || '', firstName: data.firstName || '', lastName: data.lastName || '',
              cellPhone: data.cellPhone || data.phoneNumber || '', officePhone: data.officePhone || '',
              officeExt: data.officeExt || '', publicEmail: data.publicEmail || user.email || '',
              locationType: data.locationType || 'Armory', address1: data.address1 || '',
              address2: data.address2 || '', city: data.city || '', state: data.state || 'FL',
              zip: data.zip || '', instagram: data.instagram || '', facebook: data.facebook || '',
              tiktok: data.tiktok || '', linkedin: data.linkedin || '', discord: data.discord || '',
              youtube: data.youtube || '', linktree: data.linktree || '', 
              platoons: loadedPlatoons,
              smsTemplate: data.smsTemplate || 'Hey {{name}}, this is {{recruiter}} with the FLARNG. Are you still interested in leveling up your career?',
              emailTemplate: data.emailTemplate || 'Hello {{name}},\n\nThank you for your interest in the Florida Army National Guard. Let me know when you have time for a quick call to discuss your options.\n\nRespectfully,\n{{recruiter}}'
            });
          } else {
            if (isMaster) {
              await setDoc(doc(db, 'users', user.uid), {
                uid: user.uid, email: user.email, displayName: user.displayName || 'Commander',
                role: 'admin', platoons: ['HQ', 'C1', 'C2', 'C3', 'C4'], createdAt: new Date().toISOString()
              });
              setUserRole('admin');
              setUserPlatoons(['HQ', 'C1', 'C2', 'C3', 'C4']);
            } else if (user.email) {
              const preApprovedDoc = await getDoc(doc(db, 'pre_approved_users', user.email.toLowerCase()));
              if (preApprovedDoc.exists()) {
                const preApprovedData = preApprovedDoc.data();
                const loadedPlatoons = preApprovedData.platoons || (preApprovedData.platoon ? [preApprovedData.platoon] : ['HQ']);
                await setDoc(doc(db, 'users', user.uid), {
                  uid: user.uid, email: user.email, displayName: preApprovedData.displayName || user.displayName || 'Recruiter',
                  role: preApprovedData.role, slug: preApprovedData.slug, platoons: loadedPlatoons,
                  createdAt: new Date().toISOString()
                });
                setUserRole(preApprovedData.role);
                setUserSlug(preApprovedData.slug);
                setUserPlatoons(loadedPlatoons);
                const parts = (preApprovedData.displayName || '').split(' ');
                setProfileData(prev => ({ ...prev, firstName: parts[0] || '', lastName: parts.slice(1).join(' '), platoons: loadedPlatoons }));
              } else {
                await setDoc(doc(db, 'users', user.uid), {
                  uid: user.uid, email: user.email, displayName: user.displayName || 'Recruiter',
                  role: 'pending', createdAt: new Date().toISOString()
                });
                setUserRole('pending');
                setError('Account pending admin approval.');
              }
            }
          }
        } catch (err) {
          console.error("Error fetching user role:", err);
        }
      } else {
        setUserRole(null); setUserSlug(null); setIsLoading(false);
      }
    });
    return () => unsubscribe();
  }, []);

  // Firestore Real-time Listeners (Frontend Filtering)
  useEffect(() => {
    if (!isFirebaseAuthenticated || !userRole) return;

    const leadsRef = collection(db, 'leads');
    const subsRef = collection(db, 'subscriptions');
    const usersRef = collection(db, 'users');
    
    const qLeads = query(leadsRef, orderBy('timestamp', 'desc'));
    const unsubscribeLeads = onSnapshot(qLeads, (snapshot) => {
      let leadsData = snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() })) as (Lead & { id: string })[];
      
      if (!isCommander) {
        if (userRole === 'admin') {
          leadsData = leadsData.filter(l => {
            const leadPlat = (l as any).platoon || 'HQ';
            return userPlatoons.includes(leadPlat);
          });
        } else {
          leadsData = leadsData.filter(l => l.recruiterId === auth.currentUser?.uid);
        }
      }
      setLeads(leadsData);
      setIsLoading(false);
    });

    const qSubs = query(subsRef, orderBy('timestamp', 'desc'));
    const unsubscribeSubs = onSnapshot(qSubs, (snapshot) => {
      let subsData = snapshot.docs.map(doc => ({ id: doc.id, status: 'New', ...doc.data() })) as (Subscription & { id: string, status?: string })[];
      
      if (!isCommander) {
        if (userRole === 'admin') {
          subsData = subsData.filter(s => {
            const subPlat = (s as any).platoon || 'HQ';
            return userPlatoons.includes(subPlat);
          });
        } else {
          subsData = subsData.filter(s => (s as any).recruiterId === auth.currentUser?.uid);
        }
      }
      setSubscriptions(subsData);
    });

    let qTeam = query(usersRef, orderBy('createdAt', 'desc'));
    const unsubscribeTeam = onSnapshot(qTeam, (snapshot) => {
      let teamData = snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() }));
      
      teamData = teamData.map(t => ({ ...t, platoons: (t as any).platoons || ((t as any).platoon ? [(t as any).platoon] : ['HQ']) }));

      if (!isCommander && userRole === 'admin') {
        teamData = teamData.filter(t => {
           const tp = (t as any).platoons as string[];
           return tp.some(p => userPlatoons.includes(p));
        });
      }
      setTeam(teamData);
    });

    return () => {
      unsubscribeLeads(); unsubscribeSubs(); unsubscribeTeam();
    };
  }, [isFirebaseAuthenticated, userRole, userPlatoons, isCommander]);

  // --- HELPERS ---
  const isLeadStale = (lead: any) => {
    if (lead.status !== 'New' && lead.status !== 'Contacted') return false;
    let lastAction = new Date(lead.timestamp).getTime();
    if (lead.notes && lead.notes.length > 0) {
      lastAction = Math.max(lastAction, new Date(lead.notes[lead.notes.length - 1].timestamp).getTime());
    }
    const hoursSince = (Date.now() - lastAction) / (1000 * 60 * 60);
    return hoursSince > 72;
  };

  const isFollowUpDue = (lead: any) => {
    if (!lead.followUpDate) return false;
    const today = new Date();
    today.setHours(0, 0, 0, 0);
    const due = new Date(lead.followUpDate);
    due.setHours(0, 0, 0, 0);
    return due.getTime() <= today.getTime();
  };

  const getCommsLink = (type: 'sms' | 'email', lead: any) => {
    const recruiterName = `${profileData.rank} ${profileData.lastName}`.trim() || 'your recruiter';
    if (type === 'sms') {
      const body = profileData.smsTemplate.replace(/{{name}}/g, lead.firstName).replace(/{{recruiter}}/g, recruiterName);
      return `sms:${lead.phone}?body=${encodeURIComponent(body)}`;
    } else {
      const body = profileData.emailTemplate.replace(/{{name}}/g, lead.firstName).replace(/{{recruiter}}/g, recruiterName);
      return `mailto:${lead.email}?subject=Florida Army National Guard&body=${encodeURIComponent(body)}`;
    }
  };

  // --- ACTIONS ---

  const handleInlineStatusUpdate = async (id: string, newStatus: string, type: 'lead' | 'sub' = 'lead') => {
    try {
      const col = type === 'lead' ? 'leads' : 'subscriptions';
      await updateDoc(doc(db, col, id), { status: newStatus });
    } catch (err) {
      console.error(`Error updating ${type} status:`, err);
    }
  };

  const handleInlineRoleUpdate = async (id: string, newRole: string) => {
    try { await updateDoc(doc(db, 'users', id), { role: newRole }); } 
    catch (err) { console.error("Error updating role:", err); }
  };

  const handleManualAddLead = async (e: React.MouseEvent | React.FormEvent) => {
    e.preventDefault();
    if (!auth.currentUser) return;
    
    if (!newLeadData.firstName || !newLeadData.lastName || !newLeadData.email) {
      alert("Validation Error: Please fill in the First Name, Last Name, and Email fields.");
      return;
    }

    try {
      const generatedName = `${profileData.rank} ${profileData.lastName}`.trim();
      const assignedPlatoon = profileData.platoons && profileData.platoons.length > 0 ? profileData.platoons[0] : 'HQ';
      
      const payload: any = {
        firstName: newLeadData.firstName, lastName: newLeadData.lastName,
        phone: newLeadData.phone, email: newLeadData.email,
        timestamp: new Date().toISOString(), status: 'New',
        recruiterId: auth.currentUser.uid,
        recruiterName: generatedName,
        platoon: assignedPlatoon,
        optIn: true
      };

      if (activeTab === 'leads') {
        payload.age = newLeadData.age || '';
        payload.education = newLeadData.education || 'HS Graduate';
        payload.interest = newLeadData.interest || 'Enlisted';
        payload.mos = newLeadData.mos || 'TBD';
        payload.source = newLeadData.source || 'Manual Entry';
      }

      if (activeTab === 'subscriptions') {
        payload.name = `${newLeadData.firstName} ${newLeadData.lastName}`.trim();
      }

      await addDoc(collection(db, activeTab === 'leads' ? 'leads' : 'subscriptions'), payload);
      alert(`Success! Added to ${activeTab === 'leads' ? 'Leads' : 'Subscriptions'}.`);
      setShowAddLeadModal(false);
      setNewLeadData({ firstName: '', lastName: '', phone: '', email: '', age: '', education: 'HS Graduate', interest: 'Enlisted', mos: 'TBD', source: 'Manual Entry' });
    } catch (err: any) {
      alert("Database Error: " + err.message);
    }
  };

  const handleCSVUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file || !auth.currentUser || !csvAssignee) {
      alert("Please select a recruiter to assign these leads to.");
      return;
    }
    
    const assignedRecruiter = team.find(t => t.uid === csvAssignee);
    if (!assignedRecruiter) return;

    const reader = new FileReader();
    reader.onload = async (event) => {
      const text = event.target?.result as string;
      if (!text) return;
      
      const rows = text.split('\n').filter(row => row.trim() !== '');
      const startIdx = rows[0].toLowerCase().includes('email') ? 1 : 0;
      let count = 0;
      
      for (let i = startIdx; i < rows.length; i++) {
        const cols = rows[i].split(',');
        if (cols.length >= 2) {
          try {
            await addDoc(collection(db, 'leads'), {
              firstName: cols[0]?.replace(/["']/g, '').trim() || 'Unknown',
              lastName: cols[1]?.replace(/["']/g, '').trim() || '',
              email: cols[2]?.replace(/["']/g, '').trim() || '',
              phone: cols[3]?.replace(/["']/g, '').trim() || '',
              source: 'CSV Import', status: 'New', mos: 'TBD',
              timestamp: new Date().toISOString(), 
              recruiterId: assignedRecruiter.uid,
              recruiterName: assignedRecruiter.displayName || 'Recruiter',
              platoon: assignedRecruiter.platoons && assignedRecruiter.platoons.length > 0 ? assignedRecruiter.platoons[0] : 'HQ'
            });
            count++;
          } catch (err) {}
        }
      }
      alert(`CSV Import Complete! Successfully assigned ${count} records to ${assignedRecruiter.displayName}.`);
      setShowCSVModal(false);
    };
    reader.readAsText(file);
    if (fileInputRef.current) fileInputRef.current.value = '';
  };

  const handleUpdateLead = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!editingLead || !(editingLead as any).id) return;
    try {
      let rName = (editingLead as any).recruiterName;
      let rPlatoon = (editingLead as any).platoon;
      if (editingLead.recruiterId) {
        const found = team.find(t => t.uid === editingLead.recruiterId);
        if (found) {
          rName = found.displayName;
          rPlatoon = found.platoons && found.platoons.length > 0 ? found.platoons[0] : 'HQ';
        }
      }

      await updateDoc(doc(db, 'leads', (editingLead as any).id), {
        firstName: editingLead.firstName, lastName: editingLead.lastName,
        phone: editingLead.phone, email: editingLead.email,
        mos: editingLead.mos, status: editingLead.status,
        recruiterId: editingLead.recruiterId,
        recruiterName: rName,
        platoon: rPlatoon,
        followUpDate: (editingLead as any).followUpDate || ''
      });
      alert("Lead Successfully Updated.");
      setEditingLead(null);
    } catch (err: any) { alert("Error: " + err.message); }
  };

  const handleAddNote = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!editingLead || !(editingLead as any).id || !newNote.trim()) return;
    
    try {
      const noteObj = {
        text: newNote.trim(),
        timestamp: new Date().toISOString(),
        author: `${profileData.rank} ${profileData.lastName}`.trim() || 'Recruiter'
      };
      const updatedNotes = [...((editingLead as any).notes || []), noteObj];
      
      await updateDoc(doc(db, 'leads', (editingLead as any).id), { notes: updatedNotes });
      setEditingLead({ ...editingLead, notes: updatedNotes } as any);
      setNewNote('');
    } catch (err: any) { alert("Error adding note: " + err.message); }
  };

  const handleUpdateSub = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!editingSub || !(editingSub as any).id) return;
    try {
      await updateDoc(doc(db, 'subscriptions', (editingSub as any).id), {
        name: editingSub.name, phone: editingSub.phone, email: editingSub.email, status: (editingSub as any).status
      });
      alert("Subscriber Successfully Updated.");
      setEditingSub(null);
    } catch (err: any) { alert("Error: " + err.message); }
  };

  const handleDeleteLead = async (id: string, type: 'lead' | 'sub' = 'lead') => {
    if (!window.confirm(`Are you sure you want to permanently delete this ${type}?`)) return;
    try {
      await deleteDoc(doc(db, type === 'lead' ? 'leads' : 'subscriptions', id));
      if (type === 'lead') setEditingLead(null);
      else setEditingSub(null);
    } catch (err) { console.error(`Error deleting ${type}:`, err); }
  };

  const handleSaveProfile = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!auth.currentUser) return;
    try {
      const generatedDisplayName = `${profileData.rank} ${profileData.firstName} ${profileData.lastName}`.trim();
      await setDoc(doc(db, 'users', auth.currentUser.uid), { ...profileData, displayName: generatedDisplayName }, { merge: true });
      alert("Profile Saved Successfully.");
      setShowProfileModal(false);
    } catch (err: any) { alert("Error: " + err.message); }
  };

  const handleCreateRecruiter = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!createRecruiterEmail) return;
    try {
      const emailLower = createRecruiterEmail.toLowerCase();
      await setDoc(doc(db, 'pre_approved_users', emailLower), {
        email: emailLower, displayName: createRecruiterName, role: createRecruiterRole, slug: createRecruiterSlug, platoons: createRecruiterPlatoons, createdAt: new Date().toISOString()
      });
      alert("Team Member Access Granted.");
      setShowCreateRecruiter(false); setCreateRecruiterEmail(''); setCreateRecruiterName(''); setCreateRecruiterRole('recruiter'); setCreateRecruiterSlug(''); setCreateRecruiterPlatoons(['HQ']);
    } catch (err: any) { alert("Error: " + err.message); }
  };

  const handleUpdateMember = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!editingMember) return;
    try {
      await updateDoc(doc(db, 'users', editingMember.uid), { role: editingMember.role, slug: editingMember.slug, platoons: editingMember.platoons });
      alert("Member Permissions Updated.");
      setEditingMember(null);
    } catch (err) { console.error("Error updating member:", err); }
  };

  const handleDeleteMember = async (memberId: string, memberEmail: string) => {
    if (!window.confirm("Are you sure you want to revoke this user's access? This will permanently delete them from the roster.")) return;
    try {
      await deleteDoc(doc(db, 'users', memberId));
      await deleteDoc(doc(db, 'pre_approved_users', memberEmail.toLowerCase()));
      setEditingMember(null);
    } catch (err) { console.error("Error deleting member:", err); }
  };

  const handleGoogleSignIn = async () => {
    try {
      const provider = new GoogleAuthProvider();
      await signInWithPopup(auth, provider);
    } catch (err) { setError("Failed to authenticate with Google"); }
  };

  const handleLogout = async () => {
    try { await signOut(auth); onBack(); } catch (err) { console.error("Logout error:", err); }
  };

  // --- FILTERING & DYNAMIC DATA ---

  const filteredLeads = leads.filter(lead => {
    const matchesSearch = lead.firstName.toLowerCase().includes(searchQuery.toLowerCase()) || lead.lastName.toLowerCase().includes(searchQuery.toLowerCase()) || lead.email.toLowerCase().includes(searchQuery.toLowerCase()) || lead.phone.includes(searchQuery) || lead.mos.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesStatus = statusFilter === 'All' || lead.status === statusFilter;
    const matchesSource = sourceFilter === 'All' || lead.source === sourceFilter;
    const matchesMos = mosFilter === 'All' || lead.mos === mosFilter;
    const matchesRecruiter = recruiterFilter === 'All' || lead.recruiterId === recruiterFilter;
    const leadDate = new Date(lead.timestamp.split(' ')[0]);
    const matchesStartDate = !startDate || leadDate >= new Date(startDate);
    const matchesEndDate = !endDate || leadDate <= new Date(endDate);
    return matchesSearch && matchesStatus && matchesSource && matchesMos && matchesRecruiter && matchesStartDate && matchesEndDate;
  });

  const filteredSubs = subscriptions.filter(sub => {
    const matchesSearch = sub.name.toLowerCase().includes(searchQuery.toLowerCase()) || sub.email.toLowerCase().includes(searchQuery.toLowerCase()) || sub.phone.includes(searchQuery);
    const matchesStatus = statusFilter === 'All' || (sub as any).status === statusFilter;
    const matchesRecruiter = recruiterFilter === 'All' || (sub as any).recruiterId === recruiterFilter;
    return matchesSearch && matchesStatus && matchesRecruiter;
  });

  const filteredTeam = team.filter(member => {
    const matchesSearch = (member.displayName || '').toLowerCase().includes(searchQuery.toLowerCase()) || (member.email || '').toLowerCase().includes(searchQuery.toLowerCase());
    // Fixed: Properly check the member's platoons array
    const matchesPlatoon = isCommander && recruiterFilter !== 'All' ? ((member as any).platoons || []).includes(recruiterFilter) : true; 
    return matchesSearch && matchesPlatoon;
  });

  const exportToCSV = (dataToExport: any[]) => {
    if(dataToExport.length === 0) return;
    const headers = Object.keys(dataToExport[0]).filter(k => k !== 'interactions' && k !== 'id' && k !== 'notes');
    const rows = dataToExport.map(item => headers.map(h => `"${item[h] || ''}"`).join(','));
    const csvContent = [headers.join(','), ...rows].join('\n');
    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
    const link = document.createElement('a');
    link.href = URL.createObjectURL(blob);
    link.setAttribute('download', `GuardLink_Export_${new Date().toISOString().split('T')[0]}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  const toggleSelectAll = () => {
    const currentList = activeTab === 'leads' ? filteredLeads : activeTab === 'subscriptions' ? filteredSubs : filteredTeam;
    if (selectedEmails.size === currentList.length && currentList.length > 0) setSelectedEmails(new Set());
    else setSelectedEmails(new Set(currentList.map(l => l.email)));
  };

  const toggleSelectEmail = (email: string) => {
    const newSelected = new Set(selectedEmails);
    if (newSelected.has(email)) newSelected.delete(email);
    else newSelected.add(email);
    setSelectedEmails(newSelected);
  };

  const handleBulkStatusUpdate = async (newStatus: string) => {
    try {
      const col = activeTab === 'leads' ? leads : subscriptions;
      const dbCol = activeTab === 'leads' ? 'leads' : 'subscriptions';
      const updatePromises = col.filter(item => selectedEmails.has(item.email)).map(item => updateDoc(doc(db, dbCol, (item as any).id), { status: newStatus }));
      await Promise.all(updatePromises);
      setSelectedEmails(new Set());
    } catch (err) { console.error("Bulk update error:", err); }
  };
  
  const handleBulkTransfer = async (newRecruiterId: string) => {
    if(!newRecruiterId) return;
    try {
      const targetRecruiter = team.find(t => t.uid === newRecruiterId);
      if(!targetRecruiter) return;

      const col = activeTab === 'leads' ? leads : subscriptions;
      const dbCol = activeTab === 'leads' ? 'leads' : 'subscriptions';
      
      const updatePromises = col.filter(item => selectedEmails.has(item.email)).map(item => 
        updateDoc(doc(db, dbCol, (item as any).id), { 
          recruiterId: targetRecruiter.uid,
          recruiterName: targetRecruiter.displayName || 'Recruiter',
          platoon: targetRecruiter.platoons && targetRecruiter.platoons.length > 0 ? targetRecruiter.platoons[0] : 'HQ'
        })
      );
      await Promise.all(updatePromises);
      setSelectedEmails(new Set());
      alert(`Transferred ${updatePromises.length} records to ${targetRecruiter.displayName}.`);
    } catch (err) { console.error("Bulk transfer error:", err); }
  };

  const handleBulkRoleUpdate = async (newRole: string) => {
    try {
      const updatePromises = team.filter(m => selectedEmails.has(m.email)).map(m => updateDoc(doc(db, 'users', (m as any).id), { role: newRole }));
      await Promise.all(updatePromises);
      setSelectedEmails(new Set());
    } catch (err) { console.error("Bulk role update error:", err); }
  };

  const handleBulkDelete = async () => {
    if (!window.confirm(`Are you sure you want to permanently delete ${selectedEmails.size} records?`)) return;
    try {
      const col = activeTab === 'leads' ? leads : subscriptions;
      const dbCol = activeTab === 'leads' ? 'leads' : 'subscriptions';
      const deletePromises = col.filter(item => selectedEmails.has(item.email)).map(item => deleteDoc(doc(db, dbCol, (item as any).id)));
      await Promise.all(deletePromises);
      setSelectedEmails(new Set());
    } catch (err) { console.error("Bulk delete error:", err); }
  };

  // Dynamic Chart Data
  const chartData = [
    { name: 'New', value: leads.filter(l => l.status === 'New').length, color: '#FFD530' },
    { name: 'Contacted', value: leads.filter(l => l.status === 'Contacted').length, color: '#3b82f6' },
    { name: 'Appt Set', value: leads.filter(l => l.status === 'Appointment').length, color: '#a855f7' },
    { name: 'Qualified', value: leads.filter(l => l.status === 'Qualified').length, color: '#10b981' },
    { name: 'Enlisted', value: leads.filter(l => l.status === 'Enlisted').length, color: '#ffffff' },
  ];

  const sourceCount = leads.reduce((acc: Record<string, number>, lead) => {
    const s = lead.source || 'Unknown';
    acc[s] = (acc[s] || 0) + 1;
    return acc;
  }, {});
  const dynamicSourceData = Object.keys(sourceCount).map((key, index) => ({ name: key, count: sourceCount[key], color: CHART_COLORS[index % CHART_COLORS.length] }));

  if (!isFirebaseAuthenticated || !userRole || userRole === 'pending') {
    return (
      <div className="min-h-screen flex items-center justify-center bg-army-black p-4 relative overflow-hidden">
        <div className="scanline" />
        <div className="w-full max-w-md hud-border p-6 md:p-8 border-army-gold/30">
          <div className="text-center mb-8">
            <div className="w-16 h-16 bg-army-gold/10 rounded-full flex items-center justify-center mx-auto mb-4 border border-army-gold/40 glow-border">
              <ShieldAlert className="w-8 h-8 text-army-gold" />
            </div>
            <h2 className="text-2xl font-black uppercase tracking-tight glow-text">Secure <span className="text-army-gold">Access</span></h2>
            <p className="text-zinc-500 text-[10px] font-mono uppercase tracking-widest mt-2">// Authorization_Required // Level_01_Clearance</p>
          </div>
          <div className="space-y-6">
            {userRole === 'pending' ? (
              <div className="space-y-4 text-center">
                <p className="text-army-gold text-xs font-mono uppercase tracking-widest border border-army-gold/30 bg-army-gold/10 p-4">Account pending admin approval. Please contact your section chief.</p>
                <button onClick={() => signOut(auth)} className="w-full bg-zinc-900 border border-zinc-800 text-white py-4 font-black uppercase text-xs hover:bg-zinc-800 transition-colors">Sign Out</button>
              </div>
            ) : (
              <>
                {!isFirebaseAuthenticated && (
                  <button onClick={handleGoogleSignIn} className="w-full flex items-center justify-center gap-3 bg-white text-black py-4 font-black uppercase text-xs hover:bg-zinc-200 transition-colors"><LogIn className="w-4 h-4" /> Sign In with Google</button>
                )}
                {isFirebaseAuthenticated && !userRole && (
                  <div className="flex flex-col items-center justify-center py-8 space-y-4"><Loader2 className="w-8 h-8 text-army-gold animate-spin" /><p className="text-army-gold text-[10px] font-mono uppercase tracking-widest animate-pulse">Verifying_Clearance...</p></div>
                )}
              </>
            )}
            {error && <motion.p initial={{ opacity: 0, y: -10 }} animate={{ opacity: 1, y: 0 }} className="text-red-500 text-[10px] font-black uppercase tracking-widest text-center bg-red-500/10 py-2 border border-red-500/30">[Error]: {error}</motion.p>}
            <button type="button" onClick={onBack} className="w-full text-zinc-500 font-black uppercase text-[10px] tracking-[0.3em] hover:text-white transition-colors">Abort_Mission</button>
          </div>
        </div>
      </div>
    );
  }

  const headerDisplayName = `${profileData.rank} ${profileData.lastName}`.trim() || 'Recruiter';

  return (
    <div className="min-h-screen bg-army-black text-white font-sans selection:bg-army-gold selection:text-army-black relative pb-20">
      <div className="scanline" />
      <input type="file" accept=".csv" ref={fileInputRef} onChange={handleCSVUpload} className="hidden" />
      
      {/* Header */}
      <header className="bg-army-black/80 backdrop-blur-md border-b border-army-gold/20 py-3 md:py-4 px-4 md:px-6 flex justify-between items-center sticky top-0 z-[40]">
        <div className="flex items-center gap-2 md:gap-4">
          <button onClick={onBack} className="p-1 md:p-2 hover:bg-army-gold/10 border border-transparent hover:border-army-gold/30 transition-all"><ArrowLeft className="w-4 h-4 md:w-5 md:h-5 text-army-gold" /></button>
          <div className="flex flex-col">
            <h1 className="text-lg md:text-xl font-black uppercase tracking-tighter glow-text">Command <span className="text-army-gold">Center</span></h1>
            <span className="text-[7px] md:text-[8px] font-mono text-zinc-500 uppercase tracking-widest leading-none mt-0.5">// Platoon Access: {userPlatoons.join(', ')}</span>
          </div>
        </div>
        <div className="flex items-center gap-3 md:gap-6">
          <div className="hidden sm:flex items-center gap-3 px-4 py-2 bg-army-gold/5 border border-army-gold/20">
            <div className="w-8 h-8 bg-army-gold flex items-center justify-center text-army-black font-black text-xs">{profileData.lastName ? profileData.lastName.substring(0,2).toUpperCase() : 'RC'}</div>
            <div className="flex flex-col">
              <span className="text-[10px] font-black uppercase tracking-tighter leading-none">{headerDisplayName}</span>
              <span className="text-[8px] font-mono text-army-gold uppercase">{isCommander ? 'Master_Command' : userRole === 'admin' ? 'Section_Chief' : 'Field_Agent'}</span>
            </div>
          </div>
          <button onClick={() => setShowProfileModal(true)} className="p-2 text-zinc-500 hover:text-army-gold hover:bg-army-gold/10 border border-transparent hover:border-army-gold/30 transition-all"><Settings className="w-4 h-4 md:w-5 md:h-5" /></button>
          <button onClick={() => setIsDarkMode(!isDarkMode)} className="p-2 text-zinc-500 hover:text-army-gold hover:bg-army-gold/10 border border-transparent hover:border-army-gold/30 transition-all">{isDarkMode ? <Sun className="w-4 h-4 md:w-5 md:h-5" /> : <Moon className="w-4 h-4 md:w-5 md:h-5" />}</button>
          <button onClick={() => setShowLogoutConfirm(true)} className="p-2 text-zinc-500 hover:text-red-500 hover:bg-red-500/10 border border-transparent hover:border-red-500/30 transition-all"><LogOut className="w-4 h-4 md:w-5 md:h-5" /></button>
        </div>
      </header>

      <main className="p-4 md:p-6 max-w-7xl mx-auto space-y-6 md:space-y-8">
        {/* INTERACTIVE STATS CARDS */}
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 md:gap-6">
          <button onClick={() => { setActiveTab('leads'); setStatusFilter('All'); }} className="text-left hud-border p-4 md:p-6 flex items-center justify-between group hover:border-neon-cyan/60 hover:bg-neon-cyan/5 transition-all">
            <div><p className="text-zinc-500 text-[10px] font-black uppercase tracking-widest mb-1 group-hover:text-neon-cyan/70">Total_Pipeline</p><p className="text-2xl md:text-3xl font-black tracking-tighter text-neon-cyan">{leads.length}</p></div>
            <div className="p-2 md:p-3 bg-white/5 border border-white/10 group-hover:border-neon-cyan/30 transition-all text-neon-cyan"><Users className="w-5 h-5 md:w-6 md:h-6 opacity-80" /></div>
          </button>
          <button onClick={() => { setActiveTab('leads'); setStatusFilter('New'); }} className="text-left hud-border p-4 md:p-6 flex items-center justify-between group hover:border-neon-green/60 hover:bg-neon-green/5 transition-all">
            <div><p className="text-zinc-500 text-[10px] font-black uppercase tracking-widest mb-1 group-hover:text-neon-green/70">New_Intel</p><p className="text-2xl md:text-3xl font-black tracking-tighter text-neon-green">{leads.filter(l => l.status === 'New').length}</p></div>
            <div className="p-2 md:p-3 bg-white/5 border border-white/10 group-hover:border-neon-green/30 transition-all text-neon-green"><TrendingUp className="w-5 h-5 md:w-6 md:h-6 opacity-80" /></div>
          </button>
          <button onClick={() => { setActiveTab('leads'); setStatusFilter('Appointment'); }} className="text-left hud-border p-4 md:p-6 flex items-center justify-between group hover:border-purple-500/60 hover:bg-purple-500/5 transition-all">
            <div><p className="text-zinc-500 text-[10px] font-black uppercase tracking-widest mb-1 group-hover:text-purple-500/70">Appointments</p><p className="text-2xl md:text-3xl font-black tracking-tighter text-purple-500">{leads.filter(l => l.status === 'Appointment').length}</p></div>
            <div className="p-2 md:p-3 bg-white/5 border border-white/10 group-hover:border-purple-500/30 transition-all text-purple-500"><Clock className="w-5 h-5 md:w-6 md:h-6 opacity-80" /></div>
          </button>
          <button onClick={() => { setActiveTab('leads'); setStatusFilter('Enlisted'); }} className="text-left hud-border p-4 md:p-6 flex items-center justify-between group hover:border-white/60 hover:bg-white/5 transition-all">
            <div><p className="text-zinc-500 text-[10px] font-black uppercase tracking-widest mb-1 group-hover:text-zinc-300">Enlistments</p><p className="text-2xl md:text-3xl font-black tracking-tighter text-white">{leads.filter(l => l.status === 'Enlisted').length}</p></div>
            <div className="p-2 md:p-3 bg-white/5 border border-white/10 group-hover:border-white/30 transition-all text-white"><CheckCircle className="w-5 h-5 md:w-6 md:h-6 opacity-80" /></div>
          </button>
        </div>

        {/* Charts (Dynamic Data) */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          <div className="lg:col-span-2 hud-border p-6">
            <div className="flex items-center justify-between mb-8">
              <h3 className="text-sm font-black uppercase tracking-widest glow-text">Intel_Pipeline <span className="text-army-gold">// Status</span></h3>
            </div>
            <div className="h-[300px]">
              <ResponsiveContainer width="100%" height="100%">
                <BarChart data={chartData}>
                  <CartesianGrid strokeDasharray="3 3" stroke="#1a1a1a" vertical={false} />
                  <XAxis dataKey="name" stroke="#52525b" fontSize={10} fontWeight="bold" tickLine={false} axisLine={false} />
                  <YAxis stroke="#52525b" fontSize={10} fontWeight="bold" tickLine={false} axisLine={false} />
                  <Tooltip contentStyle={{ backgroundColor: '#030000', border: '1px solid rgba(255, 213, 48, 0.3)', borderRadius: '0px', fontFamily: 'monospace' }} itemStyle={{ color: '#FFD530', fontSize: '10px', fontWeight: 'bold' }} cursor={{ fill: 'rgba(255, 213, 48, 0.05)' }} />
                  <Bar dataKey="value" fill="#FFD530" radius={[0, 0, 0, 0]}>
                    {chartData.map((entry, index) => <Cell key={`cell-${index}`} fill={entry.color} />)}
                  </Bar>
                </BarChart>
              </ResponsiveContainer>
            </div>
          </div>
          <div className="hud-border p-6">
            <h3 className="text-sm font-black uppercase tracking-widest mb-8 glow-text">Source_Intel <span className="text-army-gold">// Origin</span></h3>
            <div className="h-[300px]">
              <ResponsiveContainer width="100%" height="100%">
                <PieChart>
                  <Pie data={dynamicSourceData} cx="50%" cy="50%" innerRadius={60} outerRadius={80} paddingAngle={5} dataKey="count" stroke="none">
                    {dynamicSourceData.map((entry, index) => <Cell key={`cell-${index}`} fill={entry.color} />)}
                  </Pie>
                  <Tooltip contentStyle={{ backgroundColor: '#030000', border: '1px solid rgba(255, 213, 48, 0.3)', borderRadius: '0px', fontFamily: 'monospace' }} />
                </PieChart>
              </ResponsiveContainer>
            </div>
          </div>
        </div>

        {/* Tab Switcher */}
        <div className="flex flex-wrap gap-2 md:gap-4 mb-6">
          <button onClick={() => {setActiveTab('leads'); setSelectedEmails(new Set());}} className={cn("px-4 md:px-8 py-2 md:py-3 font-black uppercase italic text-[10px] md:text-xs tracking-widest transition-all border-2", activeTab === 'leads' ? "bg-army-gold text-army-black border-army-gold shadow-[0_0_15px_rgba(212,175,55,0.4)]" : "bg-transparent text-zinc-500 border-zinc-800 hover:border-zinc-600")}>
            <div className="flex items-center gap-2"><Users className="w-3 h-3 md:w-4 md:h-4" /> Recruitment_Leads</div>
          </button>
          <button onClick={() => {setActiveTab('subscriptions'); setSelectedEmails(new Set());}} className={cn("px-4 md:px-8 py-2 md:py-3 font-black uppercase italic text-[10px] md:text-xs tracking-widest transition-all border-2", activeTab === 'subscriptions' ? "bg-army-gold text-army-black border-army-gold shadow-[0_0_15px_rgba(212,175,55,0.4)]" : "bg-transparent text-zinc-500 border-zinc-800 hover:border-zinc-600")}>
            <div className="flex items-center gap-2"><Bell className="w-3 h-3 md:w-4 md:h-4" /> Intel_Subscribers</div>
          </button>
          {(userRole === 'admin' || isCommander) && (
            <button onClick={() => {setActiveTab('team'); setSelectedEmails(new Set());}} className={cn("px-4 md:px-8 py-2 md:py-3 font-black uppercase italic text-[10px] md:text-xs tracking-widest transition-all border-2", activeTab === 'team' ? "bg-army-gold text-army-black border-army-gold shadow-[0_0_15px_rgba(212,175,55,0.4)]" : "bg-transparent text-zinc-500 border-zinc-800 hover:border-zinc-600")}>
              <div className="flex items-center gap-2"><ShieldAlert className="w-3 h-3 md:w-4 md:h-4" /> Recruiter_Team</div>
            </button>
          )}
        </div>

        {/* Table Area */}
        <div className="hud-border overflow-hidden bg-army-black/50">
          <div className="p-4 md:p-6 border-b border-army-gold/10 flex flex-col lg:flex-row justify-between items-start lg:items-center gap-4">
            <div className="flex flex-col">
              <h3 className="text-sm md:text-base font-black uppercase tracking-widest glow-text">
                {activeTab === 'leads' ? 'Recent_Leads' : activeTab === 'subscriptions' ? 'Recent_Subscribers' : 'Recruiter_Team'} 
              </h3>
              <span className="text-[8px] font-mono text-zinc-500 uppercase tracking-widest mt-1">
                Total_Records: {activeTab === 'leads' ? filteredLeads.length : activeTab === 'subscriptions' ? filteredSubs.length : filteredTeam.length} 
              </span>
            </div>
            <div className="flex flex-wrap gap-2 w-full lg:w-auto">
              {(activeTab === 'leads' || activeTab === 'subscriptions') && (
                <>
                  <button onClick={() => setShowAddLeadModal(true)} className="px-4 py-2 bg-army-gold/10 border border-army-gold/50 text-army-gold text-[10px] font-black uppercase tracking-widest hover:bg-army-gold hover:text-army-black flex items-center gap-2 transition-colors">
                    <Plus className="w-4 h-4" /> Add_Record
                  </button>
                  {(userRole === 'admin' || isCommander) && activeTab === 'leads' && (
                    <button onClick={() => setShowCSVModal(true)} className="px-4 py-2 bg-zinc-900 border border-zinc-800 text-zinc-400 text-[10px] font-black uppercase tracking-widest hover:border-army-gold hover:text-army-gold flex items-center gap-2 transition-colors">
                      <Upload className="w-4 h-4" /> Import_CSV
                    </button>
                  )}
                </>
              )}
              {(userRole === 'admin' || isCommander) && activeTab === 'team' && (
                <button onClick={() => setShowCreateRecruiter(true)} className="px-4 py-2 bg-army-gold/10 border border-army-gold/50 text-army-gold text-[10px] font-black uppercase tracking-widest hover:bg-army-gold hover:text-army-black flex items-center gap-2 transition-colors">
                  <UserPlus className="w-4 h-4" /> Create_Recruiter
                </button>
              )}
              <div className="relative flex-1 lg:w-64 min-w-[200px]">
                <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-zinc-500" />
                <input placeholder="Search_Database..." className="w-full bg-zinc-950/50 border border-zinc-800 py-2 pl-10 pr-4 text-xs font-mono focus:border-army-gold outline-none text-army-gold" value={searchQuery} onChange={e => setSearchQuery(e.target.value)} />
              </div>
              <button onClick={() => setShowFilters(!showFilters)} className={cn("p-2 border border-zinc-800 hover:border-army-gold/50 transition-colors", showFilters ? "bg-army-gold/10 border-army-gold text-army-gold" : "bg-zinc-900/50 text-zinc-500")}><Filter className="w-5 h-5" /></button>
              <button onClick={() => exportToCSV(activeTab === 'leads' ? filteredLeads : activeTab === 'subscriptions' ? filteredSubs : filteredTeam)} className="p-2 bg-zinc-900/50 border border-zinc-800 text-zinc-500 hover:text-army-gold hover:border-army-gold/50 transition-colors"><Download className="w-5 h-5" /></button>
            </div>
          </div>

          {/* Filters Expanded */}
          <AnimatePresence>
            {showFilters && (
              <motion.div initial={{ height: 0, opacity: 0 }} animate={{ height: 'auto', opacity: 1 }} exit={{ height: 0, opacity: 0 }} className="p-4 md:p-6 border-b border-army-gold/10 bg-army-gold/5 grid grid-cols-2 md:grid-cols-5 gap-4 overflow-hidden">
                
                {(activeTab === 'leads' || activeTab === 'subscriptions') && (
                  <div className="space-y-1 col-span-2 md:col-span-1">
                    <label className="text-[8px] font-black text-zinc-500 uppercase font-mono">Status_Code</label>
                    <select value={statusFilter} onChange={e => setStatusFilter(e.target.value)} className="w-full bg-army-black border border-zinc-800 p-2 text-[10px] font-black uppercase focus:border-army-gold outline-none text-white">
                      <option value="All">All_Status</option>
                      {LEAD_STATUSES.map(status => <option key={status} value={status}>{status}</option>)}
                    </select>
                  </div>
                )}

                {(userRole === 'admin' || isCommander) && (
                  <div className="space-y-1 col-span-2 md:col-span-1">
                    <label className="text-[8px] font-black text-zinc-500 uppercase font-mono">{activeTab === 'team' && isCommander ? 'Platoon_Filter' : 'Assigned_Recruiter'}</label>
                    <select value={recruiterFilter} onChange={e => setRecruiterFilter(e.target.value)} className="w-full bg-army-black border border-zinc-800 p-2 text-[10px] font-black uppercase focus:border-army-gold outline-none text-white">
                      <option value="All">All_{activeTab === 'team' && isCommander ? 'Platoons' : 'Recruiters'}</option>
                      {activeTab === 'team' && isCommander ? (
                        PLATOONS.map(p => <option key={p} value={p}>{p}</option>)
                      ) : (
                        team.map(member => <option key={member.uid} value={member.uid}>{member.displayName} ({(member.platoons || []).join(', ')})</option>)
                      )}
                    </select>
                  </div>
                )}

                {activeTab === 'leads' && (
                  <>
                    <div className="space-y-1">
                      <label className="text-[8px] font-black text-zinc-500 uppercase font-mono">Origin_Source</label>
                      <select value={sourceFilter} onChange={e => setSourceFilter(e.target.value)} className="w-full bg-army-black border border-zinc-800 p-2 text-[10px] font-black uppercase focus:border-army-gold outline-none text-white">
                        <option value="All">All_Sources</option><option value="Instagram">Instagram</option><option value="CSV Import">CSV Import</option><option value="Manual Entry">Manual Entry</option><option value="Website">Website</option>
                      </select>
                    </div>
                    <div className="space-y-1">
                      <label className="text-[8px] font-black text-zinc-500 uppercase font-mono">MOS_ID</label>
                      <select value={mosFilter} onChange={e => setMosFilter(e.target.value)} className="w-full bg-army-black border border-zinc-800 p-2 text-[10px] font-black uppercase focus:border-army-gold outline-none text-white">
                        <option value="All">All_MOS</option><option value="TBD">TBD</option><option value="11B">11B</option><option value="68W">68W</option>
                      </select>
                    </div>
                  </>
                )}
                <div className="space-y-1">
                  <label className="text-[8px] font-black text-zinc-500 uppercase font-mono">Start_Date</label>
                  <input type="date" value={startDate} onChange={e => setStartDate(e.target.value)} className="w-full bg-army-black border border-zinc-800 p-2 text-[10px] font-black uppercase focus:border-army-gold outline-none text-white" />
                </div>
                <div className="space-y-1">
                  <label className="text-[8px] font-black text-zinc-500 uppercase font-mono">End_Date</label>
                  <input type="date" value={endDate} onChange={e => setEndDate(e.target.value)} className="w-full bg-army-black border border-zinc-800 p-2 text-[10px] font-black uppercase focus:border-army-gold outline-none text-white" />
                </div>
              </motion.div>
            )}
          </AnimatePresence>

          {/* Bulk Actions */}
          {selectedEmails.size > 0 && (
            <motion.div initial={{ y: -10, opacity: 0 }} animate={{ y: 0, opacity: 1 }} className="bg-army-gold p-3 flex flex-wrap items-center justify-between gap-4">
              <div className="flex flex-wrap items-center gap-4">
                <span className="text-army-black font-black uppercase text-[10px] tracking-widest">{selectedEmails.size} Selected</span>
                
                {activeTab === 'team' ? (
                  <select onChange={(e) => handleBulkRoleUpdate(e.target.value)} className="bg-army-black text-army-gold px-2 py-1 text-[10px] font-black uppercase outline-none cursor-pointer border border-army-black">
                    <option value="">-- Change Role --</option>
                    <option value="recruiter">Recruiter</option>
                    <option value="admin">Admin (Section Chief)</option>
                  </select>
                ) : (
                  <>
                    <select onChange={(e) => handleBulkStatusUpdate(e.target.value)} className="bg-army-black text-army-gold px-2 py-1 text-[10px] font-black uppercase outline-none cursor-pointer border border-army-black">
                      <option value="">-- Change Status --</option>
                      {LEAD_STATUSES.map(s => <option key={s} value={s}>{s}</option>)}
                    </select>

                    <select onChange={(e) => handleBulkTransfer(e.target.value)} className="bg-army-black text-neon-cyan px-2 py-1 text-[10px] font-black uppercase outline-none cursor-pointer border border-army-black">
                      <option value="">-- Transfer To --</option>
                      {team.map(m => <option key={m.uid} value={m.uid}>{m.displayName} ({(m.platoons || []).join(', ')})</option>)}
                    </select>

                    <button onClick={handleBulkDelete} className="bg-red-600 text-white px-2 py-1 text-[10px] font-black uppercase hover:bg-red-700 transition-colors flex items-center gap-1 border border-red-600">
                      <Trash2 className="w-3 h-3" /> Delete All
                    </button>
                  </>
                )}
              </div>
              <button onClick={() => setSelectedEmails(new Set())} className="text-army-black/70 hover:text-army-black font-black uppercase text-[10px]">Cancel</button>
            </motion.div>
          )}

          <div className="overflow-x-auto w-full">
            <table className="w-full text-left border-collapse min-w-[1000px]">
              <thead>
                <tr className="bg-zinc-900/50 text-zinc-400 text-[9px] font-black uppercase tracking-widest border-b border-zinc-800">
                  {activeTab === 'leads' ? (
                    <>
                      <th className="py-4 px-4 w-10"><button onClick={toggleSelectAll} className="hover:text-army-gold">{selectedEmails.size === filteredLeads.length && filteredLeads.length > 0 ? <CheckSquare className="w-4 h-4 text-army-gold" /> : <Square className="w-4 h-4" />}</button></th>
                      <th className="py-4 px-4">Operator_Name / Contact</th>
                      <th className="py-4 px-4">Pipeline_Status</th>
                      <th className="py-4 px-4">Class_Interest</th>
                      <th className="py-4 px-4">MOS_ID</th>
                      <th className="py-4 px-4">Timestamp</th>
                      <th className="py-4 px-4 text-right">Actions</th>
                    </>
                  ) : activeTab === 'subscriptions' ? (
                    <>
                      <th className="py-4 px-4 w-10"><button onClick={toggleSelectAll} className="hover:text-army-gold">{selectedEmails.size === filteredSubs.length && filteredSubs.length > 0 ? <CheckSquare className="w-4 h-4 text-army-gold" /> : <Square className="w-4 h-4" />}</button></th>
                      <th className="py-4 px-4">Subscriber_Name / Contact</th>
                      <th className="py-4 px-4">Pipeline_Status</th>
                      <th className="py-4 px-4">Origin</th>
                      <th className="py-4 px-4">Timestamp</th>
                      <th className="py-4 px-4 text-right">Actions</th>
                    </>
                  ) : (
                    <>
                      <th className="py-4 px-4 w-10"><button onClick={toggleSelectAll} className="hover:text-army-gold">{selectedEmails.size === filteredTeam.length && filteredTeam.length > 0 ? <CheckSquare className="w-4 h-4 text-army-gold" /> : <Square className="w-4 h-4" />}</button></th>
                      <th className="py-4 px-4">Recruiter_Name</th>
                      <th className="py-4 px-4">Email_Address</th>
                      <th className="py-4 px-4">Role_Access</th>
                      <th className="py-4 px-4">Personal_Link</th>
                      <th className="py-4 px-4">Joined_Date</th>
                      <th className="py-4 px-4 text-right">Actions</th>
                    </>
                  )}
                </tr>
              </thead>
              <tbody className="divide-y divide-zinc-800/50">
                {isLoading ? (
                  <tr><td colSpan={7} className="py-20 text-center"><Loader2 className="w-8 h-8 animate-spin text-army-gold mx-auto mb-4" /><p className="text-zinc-500 font-mono text-[10px] uppercase tracking-widest">Pulling_Secure_Data...</p></td></tr>
                ) : activeTab === 'leads' ? (
                  filteredLeads.length > 0 ? filteredLeads.map((lead, i) => {
                    const isStale = isLeadStale(lead);
                    const isDue = isFollowUpDue(lead);
                    
                    return (
                      <tr key={i} className={cn("group transition-colors text-sm", 
                        selectedEmails.has(lead.email) ? "bg-army-gold/5" : isStale ? "bg-red-900/10 hover:bg-red-900/20" : "hover:bg-white/5"
                      )}>
                        <td className="py-4 px-4">
                          <button onClick={() => toggleSelectEmail(lead.email)} className={isStale ? "text-red-500" : "text-zinc-500 hover:text-army-gold"}>
                            {selectedEmails.has(lead.email) ? <CheckSquare className="w-4 h-4" /> : <Square className="w-4 h-4" />}
                          </button>
                        </td>
                        <td className="py-4 px-4">
                          <div className="flex items-center gap-2">
                            {isStale && <AlertTriangle className="w-4 h-4 text-red-500 animate-pulse" title="Stale Lead (> 72 Hrs)" />}
                            <div className={cn("font-black uppercase tracking-tight", isStale ? "text-red-400" : "text-white")}>{lead.firstName} {lead.lastName}</div>
                            {isDue && <span className="bg-army-gold text-army-black text-[8px] font-black px-1.5 py-0.5 uppercase tracking-widest animate-pulse shadow-[0_0_8px_rgba(212,175,55,0.6)]">DUE</span>}
                          </div>
                          {(userRole === 'admin' || isCommander) && (
                            <div className="text-[8px] font-black text-army-gold mt-0.5 uppercase tracking-widest">
                              Assigned: {lead.recruiterName || 'Unknown'} ({lead.platoon || 'HQ'})
                            </div>
                          )}
                          {/* 1-Click Editable Comms Box */}
                          <div className="flex items-center gap-2 mt-2">
                            <a href={`tel:${lead.phone}`} className="p-1 bg-zinc-800 rounded hover:bg-army-gold hover:text-black transition-colors" title="Call"><Phone className="w-3 h-3" /></a>
                            <a href={getCommsLink('sms', lead)} className="p-1 bg-zinc-800 rounded hover:bg-army-gold hover:text-black transition-colors" title="Text (Template)"><MessageSquare className="w-3 h-3" /></a>
                            <a href={getCommsLink('email', lead)} className="p-1 bg-zinc-800 rounded hover:bg-army-gold hover:text-black transition-colors" title="Email (Template)"><Mail className="w-3 h-3" /></a>
                          </div>
                        </td>
                        <td className="py-4 px-4">
                          <select 
                            value={lead.status} 
                            onChange={(e) => handleInlineStatusUpdate((lead as any).id, e.target.value, 'lead')}
                            className={cn("text-[9px] font-black uppercase px-2 py-1.5 border outline-none cursor-pointer appearance-none text-center min-w-[90px]", 
                              lead.status === 'New' ? "bg-army-gold/10 border-army-gold/40 text-army-gold" : 
                              lead.status === 'Contacted' ? "bg-neon-cyan/10 border-neon-cyan/40 text-neon-cyan" : 
                              lead.status === 'Enlisted' ? "bg-white/10 border-white/40 text-white" :
                              "bg-neon-green/10 border-neon-green/40 text-neon-green"
                            )}
                          >
                            {LEAD_STATUSES.map(s => <option key={s} value={s} className="bg-army-black text-white">{s}</option>)}
                          </select>
                        </td>
                        <td className="py-4 px-4 text-[10px] font-black uppercase tracking-wider text-zinc-300">{lead.interest}</td>
                        <td className="py-4 px-4 text-[11px] font-mono font-bold text-army-gold">{lead.mos}</td>
                        <td className="py-4 px-4 text-[10px] font-mono text-zinc-500">{lead.timestamp.split('T')[0]}</td>
                        <td className="py-4 px-4 text-right">
                          <div className="flex justify-end gap-2 opacity-50 group-hover:opacity-100 transition-opacity">
                            <button onClick={() => setJourneyLead(lead)} className="p-2 bg-zinc-900 border border-zinc-800 hover:border-army-gold/50 text-zinc-400 hover:text-army-gold transition-colors" title="View Interaction Log"><History className="w-4 h-4" /></button>
                            <button onClick={() => setEditingLead(lead)} className="p-2 bg-zinc-900 border border-zinc-800 hover:border-army-gold/50 text-zinc-400 hover:text-army-gold transition-colors" title="Edit Lead / Notes"><Edit className="w-4 h-4" /></button>
                          </div>
                        </td>
                      </tr>
                    );
                  }) : (<tr><td colSpan={7} className="py-16 text-center text-zinc-500 font-black uppercase text-xs tracking-widest">No_Intel_Found</td></tr>)
                ) : activeTab === 'subscriptions' ? (
                  filteredSubs.length > 0 ? filteredSubs.map((sub, i) => (
                    <tr key={i} className={cn("hover:bg-white/5 text-sm transition-colors group", selectedEmails.has(sub.email) && "bg-army-gold/5")}>
                      <td className="py-4 px-4"><button onClick={() => toggleSelectEmail(sub.email)} className="text-zinc-500 hover:text-army-gold">{selectedEmails.has(sub.email) ? <CheckSquare className="w-4 h-4 text-army-gold" /> : <Square className="w-4 h-4" />}</button></td>
                      <td className="py-4 px-4">
                        <div className="font-black uppercase text-white tracking-tight">{sub.name}</div>
                        {/* 1-Click Comms Box */}
                        <div className="flex items-center gap-2 mt-2">
                          <a href={`tel:${sub.phone}`} className="p-1 bg-zinc-800 rounded hover:bg-army-gold hover:text-black transition-colors" title="Call"><Phone className="w-3 h-3" /></a>
                          <a href={`sms:${sub.phone}`} className="p-1 bg-zinc-800 rounded hover:bg-army-gold hover:text-black transition-colors" title="Text"><MessageSquare className="w-3 h-3" /></a>
                          <a href={`mailto:${sub.email}`} className="p-1 bg-zinc-800 rounded hover:bg-army-gold hover:text-black transition-colors" title="Email"><Mail className="w-3 h-3" /></a>
                        </div>
                      </td>
                      <td className="py-4 px-4">
                        <select value={(sub as any).status || 'New'} onChange={(e) => handleInlineStatusUpdate((sub as any).id, e.target.value, 'sub')} className={cn("text-[9px] font-black uppercase px-2 py-1.5 border outline-none cursor-pointer appearance-none text-center min-w-[90px]", (sub as any).status === 'New' || !(sub as any).status ? "bg-army-gold/10 border-army-gold/40 text-army-gold" : "bg-neon-cyan/10 border-neon-cyan/40 text-neon-cyan")}>
                          {LEAD_STATUSES.map(s => <option key={s} value={s} className="bg-army-black text-white">{s}</option>)}
                        </select>
                      </td>
                      <td className="py-4 px-4"><span className="text-[8px] font-black uppercase border px-2 py-1 bg-neon-green/10 text-neon-green border-neon-green/30">SUBSCRIBED</span></td>
                      <td className="py-4 px-4 font-mono text-zinc-500 text-[10px]">{sub.timestamp.split('T')[0]}</td>
                      <td className="py-4 px-4 text-right">
                        <div className="flex justify-end gap-2 opacity-50 group-hover:opacity-100 transition-opacity">
                          <button onClick={() => setEditingSub(sub)} className="p-2 bg-zinc-900 border border-zinc-800 hover:border-army-gold/50 text-zinc-400 hover:text-army-gold transition-colors" title="Edit"><Edit className="w-4 h-4" /></button>
                        </div>
                      </td>
                    </tr>
                  )) : (<tr><td colSpan={6} className="py-16 text-center text-zinc-500 font-black uppercase text-xs tracking-widest">No_Subscribers_Found</td></tr>)
                ) : (
                  filteredTeam.length > 0 ? filteredTeam.map((member, i) => (
                    <tr key={i} className={cn("hover:bg-white/5 text-sm transition-colors group", selectedEmails.has(member.email) && "bg-army-gold/5")}>
                      <td className="py-4 px-4"><button onClick={() => toggleSelectEmail(member.email)} className="text-zinc-500 hover:text-army-gold">{selectedEmails.has(member.email) ? <CheckSquare className="w-4 h-4 text-army-gold" /> : <Square className="w-4 h-4" />}</button></td>
                      <td className="py-4 px-4 font-black uppercase text-white tracking-tight">{member.displayName}</td>
                      <td className="py-4 px-4 font-mono text-army-gold text-[10px]">{member.email}</td>
                      <td className="py-4 px-4">
                        <select 
                          value={member.role || 'recruiter'} 
                          onChange={(e) => handleInlineRoleUpdate(member.id, e.target.value)} 
                          className={cn("text-[9px] font-black uppercase px-2 py-1.5 border outline-none cursor-pointer appearance-none text-center min-w-[90px]", 
                            member.role === 'admin' ? "bg-army-gold/10 border-army-gold/40 text-army-gold" : "bg-zinc-800/50 border-zinc-700 text-zinc-300"
                          )}
                        >
                          <option value="recruiter" className="bg-army-black text-white">RECRUITER</option>
                          <option value="admin" className="bg-army-black text-white">ADMIN</option>
                        </select>
                      </td>
                      <td className="py-4 px-4 font-mono text-neon-cyan text-[10px] hover:underline cursor-pointer">/?r={member.slug || 'N/A'}</td>
                      <td className="py-4 px-4 font-mono text-zinc-500 text-[10px]">{member.createdAt?.split('T')[0]}</td>
                      <td className="py-4 px-4 text-right">
                        <div className="flex justify-end gap-2 opacity-50 group-hover:opacity-100 transition-opacity">
                          <button onClick={() => setEditingMember(member)} className="p-2 bg-zinc-900 border border-zinc-800 hover:border-army-gold/50 text-zinc-400 hover:text-army-gold transition-colors" title="Edit Access"><Edit className="w-4 h-4" /></button>
                          <button onClick={() => handleDeleteMember(member.id, member.email)} className="p-2 bg-zinc-900 border border-zinc-800 hover:border-red-500/50 text-zinc-500 hover:text-red-500 transition-colors" title="Revoke Access"><Trash2 className="w-4 h-4" /></button>
                        </div>
                      </td>
                    </tr>
                  )) : (<tr><td colSpan={7} className="py-16 text-center text-zinc-500 font-black uppercase text-xs tracking-widest">No_Team_Found</td></tr>)
                )}
              </tbody>
            </table>
          </div>
        </div>
      </main>

      {/* --- MODALS --- */}

      {/* Logout Confirmation Modal */}
      <AnimatePresence>
        {showLogoutConfirm && (
          <div className="fixed inset-0 z-[70] flex items-center justify-center p-4">
            <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} className="absolute inset-0 bg-army-black/95 backdrop-blur-md" />
            <motion.div initial={{ opacity: 0, scale: 0.95 }} animate={{ opacity: 1, scale: 1 }} exit={{ opacity: 0, scale: 0.95 }} className="relative w-full max-w-sm hud-border bg-zinc-950 p-8 text-center border-red-500/30">
              <ShieldAlert className="w-12 h-12 text-red-500 mx-auto mb-6" />
              <h3 className="text-2xl font-black uppercase italic tracking-tighter text-white mb-2">Confirm_Logout</h3>
              <p className="text-[10px] font-mono text-zinc-500 uppercase tracking-widest mb-8">End secure session and return to landing zone?</p>
              <div className="flex gap-4">
                <button onClick={() => setShowLogoutConfirm(false)} className="flex-1 py-3 border border-zinc-800 text-zinc-400 font-black uppercase text-xs tracking-widest hover:bg-zinc-900 transition-colors">Cancel</button>
                <button onClick={handleLogout} className="flex-1 py-3 bg-red-600 hover:bg-red-700 text-white font-black uppercase text-xs tracking-widest transition-colors">Abort_Mission</button>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      {/* Targeted CSV Upload Modal */}
      <AnimatePresence>
        {showCSVModal && (
          <div className="fixed inset-0 z-[60] flex items-center justify-center p-4">
            <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} onClick={() => setShowCSVModal(false)} className="absolute inset-0 bg-army-black/90 backdrop-blur-sm" />
            <motion.div initial={{ opacity: 0, scale: 0.95 }} animate={{ opacity: 1, scale: 1 }} exit={{ opacity: 0, scale: 0.95 }} className="relative w-full max-w-sm hud-border bg-zinc-950 overflow-hidden flex flex-col p-6">
              <div className="flex justify-between items-center mb-6">
                <h3 className="text-xl font-black uppercase italic tracking-tighter text-army-gold">Import_CSV</h3>
                <button onClick={() => setShowCSVModal(false)} className="p-2 hover:bg-army-gold/10 text-zinc-500 hover:text-army-gold"><X className="w-4 h-4" /></button>
              </div>
              <div className="space-y-4">
                <div>
                  <label className="block text-[10px] font-black uppercase text-army-gold mb-2">Assign Leads To:</label>
                  <select value={csvAssignee} onChange={e => setCsvAssignee(e.target.value)} className="w-full bg-zinc-900 border border-zinc-800 p-3 text-white font-mono text-sm focus:border-army-gold outline-none">
                    <option value="">-- Select Recruiter --</option>
                    {team.map(m => <option key={m.uid} value={m.uid}>{m.displayName} ({(m.platoons || []).join(', ')})</option>)}
                  </select>
                </div>
                <button 
                  onClick={() => {
                    if(!csvAssignee) { alert("Please select a recruiter first."); return; }
                    fileInputRef.current?.click();
                  }} 
                  className="w-full py-4 bg-army-gold text-army-black font-black uppercase tracking-widest hover:bg-white transition-colors mt-4 flex justify-center items-center gap-2"
                >
                  <Upload className="w-4 h-4" /> Select File
                </button>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      {/* Add Manual Lead / Sub Modal */}
      <AnimatePresence>
        {showAddLeadModal && (
          <div className="fixed inset-0 z-[60] flex items-center justify-center p-4">
            <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} onClick={() => setShowAddLeadModal(false)} className="absolute inset-0 bg-army-black/90 backdrop-blur-sm" />
            <motion.div initial={{ opacity: 0, scale: 0.95 }} animate={{ opacity: 1, scale: 1 }} exit={{ opacity: 0, scale: 0.95 }} className="relative w-full max-w-xl hud-border bg-zinc-950 overflow-hidden flex flex-col">
              <div className="p-6 border-b border-army-gold/20 bg-army-gold/5 flex justify-between items-center">
                <div>
                  <h3 className="text-xl font-black uppercase italic tracking-tighter text-army-gold">Manual_Entry</h3>
                  <p className="text-[10px] font-mono text-zinc-500 uppercase tracking-widest">Add a new {activeTab === 'leads' ? 'Recruitment Lead' : 'Intel Subscriber'}</p>
                </div>
                <button onClick={() => setShowAddLeadModal(false)} className="p-2 hover:bg-army-gold/10 text-zinc-500 hover:text-army-gold"><X className="w-6 h-6" /></button>
              </div>
              <form onSubmit={handleManualAddLead} className="p-6 space-y-6">
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <label className="block text-[10px] font-black uppercase text-army-gold mb-2">First Name</label>
                    <input type="text" value={newLeadData.firstName} onChange={e => setNewLeadData({...newLeadData, firstName: e.target.value})} className="w-full bg-zinc-900 border border-zinc-800 p-3 text-white font-mono text-sm focus:border-army-gold outline-none" required />
                  </div>
                  <div>
                    <label className="block text-[10px] font-black uppercase text-army-gold mb-2">Last Name</label>
                    <input type="text" value={newLeadData.lastName} onChange={e => setNewLeadData({...newLeadData, lastName: e.target.value})} className="w-full bg-zinc-900 border border-zinc-800 p-3 text-white font-mono text-sm focus:border-army-gold outline-none" required />
                  </div>
                  <div>
                    <label className="block text-[10px] font-black uppercase text-army-gold mb-2">Phone</label>
                    <input type="tel" value={newLeadData.phone} onChange={e => setNewLeadData({...newLeadData, phone: e.target.value})} className="w-full bg-zinc-900 border border-zinc-800 p-3 text-white font-mono text-sm focus:border-army-gold outline-none" required />
                  </div>
                  <div>
                    <label className="block text-[10px] font-black uppercase text-army-gold mb-2">Email</label>
                    <input type="email" value={newLeadData.email} onChange={e => setNewLeadData({...newLeadData, email: e.target.value})} className="w-full bg-zinc-900 border border-zinc-800 p-3 text-white font-mono text-sm focus:border-army-gold outline-none" required />
                  </div>
                  {activeTab === 'leads' && (
                    <>
                      <div>
                        <label className="block text-[10px] font-black uppercase text-army-gold mb-2">Interest</label>
                        <select value={newLeadData.interest} onChange={e => setNewLeadData({...newLeadData, interest: e.target.value})} className="w-full bg-zinc-900 border border-zinc-800 p-3 text-white font-mono text-sm focus:border-army-gold outline-none">
                          <option value="Enlisted">Enlisted</option><option value="Officer">Officer</option><option value="Warrant Officer">Warrant Officer</option>
                        </select>
                      </div>
                      <div>
                        <label className="block text-[10px] font-black uppercase text-army-gold mb-2">Target MOS</label>
                        <input type="text" value={newLeadData.mos} onChange={e => setNewLeadData({...newLeadData, mos: e.target.value})} className="w-full bg-zinc-900 border border-zinc-800 p-3 text-white font-mono text-sm focus:border-army-gold outline-none" />
                      </div>
                    </>
                  )}
                </div>
                <div className="pt-4 flex justify-end gap-4 border-t border-zinc-800">
                  <button type="button" onClick={() => setShowAddLeadModal(false)} className="px-6 py-3 border border-zinc-800 text-zinc-400 font-black uppercase tracking-widest hover:bg-zinc-800 hover:text-white transition-colors">Cancel</button>
                  <button type="submit" className="px-6 py-3 bg-army-gold text-army-black font-black uppercase tracking-widest hover:bg-white transition-colors">Add_Record</button>
                </div>
              </form>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      {/* Edit Lead & CRM Notes Modal */}
      <AnimatePresence>
        {editingLead && (
          <div className="fixed inset-0 z-[60] flex items-center justify-center p-4">
            <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} onClick={() => setEditingLead(null)} className="absolute inset-0 bg-army-black/90 backdrop-blur-sm" />
            <motion.div initial={{ opacity: 0, scale: 0.95 }} animate={{ opacity: 1, scale: 1 }} exit={{ opacity: 0, scale: 0.95 }} className="relative w-full max-w-2xl hud-border bg-zinc-950 overflow-hidden flex flex-col max-h-[90vh]">
              <div className="p-6 border-b border-army-gold/20 bg-army-gold/5 flex justify-between items-center">
                <div>
                  <h3 className="text-xl font-black uppercase italic tracking-tighter text-army-gold">Edit_Intel_Record</h3>
                  <p className="text-[10px] font-mono text-zinc-500 uppercase tracking-widest">{editingLead.email}</p>
                </div>
                <button onClick={() => setEditingLead(null)} className="p-2 hover:bg-army-gold/10 text-zinc-500 hover:text-army-gold"><X className="w-6 h-6" /></button>
              </div>
              <div className="overflow-y-auto scrollbar-hide flex-1">
                <form onSubmit={handleUpdateLead} className="p-6 space-y-6">
                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <label className="block text-[10px] font-black uppercase text-army-gold mb-2">First Name</label>
                      <input type="text" value={editingLead.firstName} onChange={e => setEditingLead({...editingLead, firstName: e.target.value})} className="w-full bg-zinc-900 border border-zinc-800 p-3 text-white font-mono text-sm focus:border-army-gold outline-none" required />
                    </div>
                    <div>
                      <label className="block text-[10px] font-black uppercase text-army-gold mb-2">Last Name</label>
                      <input type="text" value={editingLead.lastName} onChange={e => setEditingLead({...editingLead, lastName: e.target.value})} className="w-full bg-zinc-900 border border-zinc-800 p-3 text-white font-mono text-sm focus:border-army-gold outline-none" required />
                    </div>
                    <div>
                      <label className="block text-[10px] font-black uppercase text-army-gold mb-2">Phone</label>
                      <input type="tel" value={editingLead.phone} onChange={e => setEditingLead({...editingLead, phone: e.target.value})} className="w-full bg-zinc-900 border border-zinc-800 p-3 text-white font-mono text-sm focus:border-army-gold outline-none" required />
                    </div>
                    <div>
                      <label className="block text-[10px] font-black uppercase text-army-gold mb-2">Email</label>
                      <input type="email" value={editingLead.email} onChange={e => setEditingLead({...editingLead, email: e.target.value})} className="w-full bg-zinc-900 border border-zinc-800 p-3 text-white font-mono text-sm focus:border-army-gold outline-none" required />
                    </div>
                    <div>
                      <label className="block text-[10px] font-black uppercase text-army-gold mb-2">Pipeline Status</label>
                      <select value={editingLead.status} onChange={e => setEditingLead({...editingLead, status: e.target.value})} className="w-full bg-zinc-900 border border-zinc-800 p-3 text-white font-mono text-sm focus:border-army-gold outline-none">
                        {LEAD_STATUSES.map(s => <option key={s} value={s}>{s}</option>)}
                      </select>
                    </div>
                    <div>
                      <label className="block text-[10px] font-black uppercase text-army-gold mb-2">Target MOS</label>
                      <input type="text" value={editingLead.mos} onChange={e => setEditingLead({...editingLead, mos: e.target.value})} className="w-full bg-zinc-900 border border-zinc-800 p-3 text-white font-mono text-sm focus:border-army-gold outline-none" />
                    </div>
                    
                    <div className="col-span-1">
                      <label className="flex items-center gap-2 text-[10px] font-black uppercase text-neon-cyan mb-2"><Forward className="w-3 h-3"/> Reassign / Transfer Lead</label>
                      <select 
                        value={editingLead.recruiterId || ''} 
                        onChange={e => setEditingLead({...editingLead, recruiterId: e.target.value})} 
                        className="w-full bg-zinc-900 border border-zinc-800 p-3 text-white font-mono text-sm focus:border-neon-cyan outline-none"
                      >
                        {team.map(m => <option key={m.uid} value={m.uid}>{m.displayName} ({(m.platoons || []).join(', ')})</option>)}
                      </select>
                    </div>
                    <div className="col-span-1">
                      <label className="flex items-center gap-2 text-[10px] font-black uppercase text-army-gold mb-2"><Calendar className="w-3 h-3"/> Follow-Up Date</label>
                      <input 
                        type="date" 
                        value={(editingLead as any).followUpDate || ''} 
                        onChange={e => setEditingLead({...editingLead, followUpDate: e.target.value} as any)} 
                        className="w-full bg-zinc-900 border border-zinc-800 p-3 text-white font-mono text-sm focus:border-army-gold outline-none" 
                      />
                    </div>
                  </div>
                  
                  {/* CRM NOTES SECTION */}
                  <div className="border-t border-zinc-800 pt-6">
                    <h4 className="text-[10px] font-black uppercase tracking-widest text-zinc-500 mb-4">// Recruiter_Notes</h4>
                    <div className="space-y-4 mb-4 max-h-40 overflow-y-auto scrollbar-hide pr-2">
                      {((editingLead as any).notes || []).map((note: any, idx: number) => (
                        <div key={idx} className="bg-zinc-900 p-3 border-l-2 border-army-gold">
                          <p className="text-xs text-white">{note.text}</p>
                          <div className="flex justify-between items-center mt-2">
                            <span className="text-[8px] font-mono text-zinc-500">{note.author}</span>
                            <span className="text-[8px] font-mono text-zinc-500">{new Date(note.timestamp).toLocaleDateString()} {new Date(note.timestamp).toLocaleTimeString()}</span>
                          </div>
                        </div>
                      ))}
                      {((editingLead as any).notes || []).length === 0 && (
                        <p className="text-[10px] font-mono text-zinc-500 italic">No notes recorded yet.</p>
                      )}
                    </div>
                    <div className="flex gap-2">
                      <input type="text" value={newNote} onChange={e => setNewNote(e.target.value)} placeholder="Add a quick note..." className="flex-1 bg-zinc-900 border border-zinc-800 p-3 text-white font-mono text-xs focus:border-army-gold outline-none" />
                      <button type="button" onClick={handleAddNote} className="px-4 bg-army-gold/10 border border-army-gold/50 text-army-gold font-black uppercase text-[10px] hover:bg-army-gold hover:text-army-black transition-colors">Add</button>
                    </div>
                  </div>

                  <div className="pt-4 flex justify-between items-center border-t border-zinc-800">
                    <button type="button" onClick={() => handleDeleteLead((editingLead as any).id, 'lead')} className="flex items-center gap-2 text-red-500 hover:bg-red-500/10 px-4 py-2 text-[10px] font-black uppercase tracking-widest transition-colors"><Trash2 className="w-4 h-4"/> Delete_Record</button>
                    <div className="flex gap-4">
                      <button type="button" onClick={() => setEditingLead(null)} className="px-6 py-3 border border-zinc-800 text-zinc-400 font-black uppercase tracking-widest hover:bg-zinc-800 hover:text-white transition-colors">Cancel</button>
                      <button type="submit" className="px-6 py-3 bg-army-gold text-army-black font-black uppercase tracking-widest hover:bg-white transition-colors">Save_Intel</button>
                    </div>
                  </div>
                </form>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      {/* Edit Subscriber Modal */}
      <AnimatePresence>
        {editingSub && (
          <div className="fixed inset-0 z-[60] flex items-center justify-center p-4">
            <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} onClick={() => setEditingSub(null)} className="absolute inset-0 bg-army-black/90 backdrop-blur-sm" />
            <motion.div initial={{ opacity: 0, scale: 0.95 }} animate={{ opacity: 1, scale: 1 }} exit={{ opacity: 0, scale: 0.95 }} className="relative w-full max-w-xl hud-border bg-zinc-950 overflow-hidden flex flex-col">
              <div className="p-6 border-b border-army-gold/20 bg-army-gold/5 flex justify-between items-center">
                <div>
                  <h3 className="text-xl font-black uppercase italic tracking-tighter text-army-gold">Edit_Subscriber</h3>
                  <p className="text-[10px] font-mono text-zinc-500 uppercase tracking-widest">{editingSub.email}</p>
                </div>
                <button onClick={() => setEditingSub(null)} className="p-2 hover:bg-army-gold/10 text-zinc-500 hover:text-army-gold"><X className="w-6 h-6" /></button>
              </div>
              <form onSubmit={handleUpdateSub} className="p-6 space-y-6">
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <label className="block text-[10px] font-black uppercase text-army-gold mb-2">Full Name</label>
                    <input type="text" value={editingSub.name} onChange={e => setEditingSub({...editingSub, name: e.target.value})} className="w-full bg-zinc-900 border border-zinc-800 p-3 text-white font-mono text-sm focus:border-army-gold outline-none" required />
                  </div>
                  <div>
                    <label className="block text-[10px] font-black uppercase text-army-gold mb-2">Phone</label>
                    <input type="tel" value={editingSub.phone} onChange={e => setEditingSub({...editingSub, phone: e.target.value})} className="w-full bg-zinc-900 border border-zinc-800 p-3 text-white font-mono text-sm focus:border-army-gold outline-none" required />
                  </div>
                  <div>
                    <label className="block text-[10px] font-black uppercase text-army-gold mb-2">Email</label>
                    <input type="email" value={editingSub.email} onChange={e => setEditingSub({...editingSub, email: e.target.value})} className="w-full bg-zinc-900 border border-zinc-800 p-3 text-white font-mono text-sm focus:border-army-gold outline-none" required />
                  </div>
                  <div>
                    <label className="block text-[10px] font-black uppercase text-army-gold mb-2">Pipeline Status</label>
                    <select value={(editingSub as any).status || 'New'} onChange={e => setEditingSub({...editingSub, status: e.target.value} as any)} className="w-full bg-zinc-900 border border-zinc-800 p-3 text-white font-mono text-sm focus:border-army-gold outline-none">
                      {LEAD_STATUSES.map(s => <option key={s} value={s}>{s}</option>)}
                    </select>
                  </div>
                </div>
                <div className="pt-4 flex justify-between items-center border-t border-zinc-800">
                  <button type="button" onClick={() => handleDeleteLead((editingSub as any).id, 'sub')} className="flex items-center gap-2 text-red-500 hover:bg-red-500/10 px-4 py-2 text-[10px] font-black uppercase tracking-widest transition-colors"><Trash2 className="w-4 h-4"/> Delete_Subscriber</button>
                  <div className="flex gap-4">
                    <button type="button" onClick={() => setEditingSub(null)} className="px-6 py-3 border border-zinc-800 text-zinc-400 font-black uppercase tracking-widest hover:bg-zinc-800 hover:text-white transition-colors">Cancel</button>
                    <button type="submit" className="px-6 py-3 bg-army-gold text-army-black font-black uppercase tracking-widest hover:bg-white transition-colors">Save_Intel</button>
                  </div>
                </div>
              </form>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      {/* User Journey Modal */}
      <AnimatePresence>
        {journeyLead && (
          <div className="fixed inset-0 z-[60] flex items-center justify-center p-4 md:p-6">
            <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} onClick={() => setJourneyLead(null)} className="absolute inset-0 bg-army-black/90 backdrop-blur-sm" />
            <motion.div initial={{ opacity: 0, scale: 0.9, y: 20 }} animate={{ opacity: 1, scale: 1, y: 0 }} exit={{ opacity: 0, scale: 0.9, y: 20 }} className="relative w-full max-w-2xl hud-border bg-zinc-950 overflow-hidden flex flex-col max-h-[80vh]">
              <div className="p-6 border-b border-army-gold/20 bg-army-gold/5 flex justify-between items-center">
                <div>
                  <h3 className="text-xl font-black uppercase italic tracking-tighter text-army-gold">User_Journey // Intel_Log</h3>
                  <p className="text-[10px] font-mono text-zinc-500 uppercase tracking-widest">{journeyLead.firstName} {journeyLead.lastName} // {journeyLead.email}</p>
                </div>
                <button onClick={() => setJourneyLead(null)} className="p-2 hover:bg-army-gold/10 text-zinc-500 hover:text-army-gold transition-colors"><X className="w-6 h-6" /></button>
              </div>

              <div className="flex-1 overflow-y-auto p-6 space-y-4 scrollbar-hide">
                {journeyLead.interactions && journeyLead.interactions.length > 0 ? (
                  <div className="space-y-4">
                    {journeyLead.interactions.map((interaction, idx) => (
                      <div key={idx} className="flex gap-4 items-start group">
                        <div className="mt-1 w-2 h-2 rounded-full bg-army-gold animate-pulse shadow-[0_0_8px_rgba(212,175,55,0.5)]" />
                        <div className="flex-1 space-y-1">
                          <div className="flex justify-between items-center">
                            <p className="text-[10px] font-black uppercase tracking-widest text-white group-hover:text-army-gold transition-colors">{interaction.element}</p>
                            <p className="text-[8px] font-mono text-zinc-600">{new Date(interaction.timestamp).toLocaleTimeString()}</p>
                          </div>
                          <p className="text-[9px] font-mono text-zinc-500 uppercase italic">Action_Type: {interaction.type}</p>
                        </div>
                      </div>
                    ))}
                  </div>
                ) : (
                  <div className="py-12 text-center">
                    <Eye className="w-12 h-12 text-zinc-800 mx-auto mb-4" />
                    <p className="text-zinc-500 font-black uppercase tracking-widest text-xs">No_Interaction_Data // Direct_Submission</p>
                  </div>
                )}
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      {/* Edit Member Modal (Admin Only) */}
      <AnimatePresence>
        {editingMember && (
          <div className="fixed inset-0 z-[60] flex items-center justify-center p-4">
            <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} onClick={() => setEditingMember(null)} className="absolute inset-0 bg-army-black/90 backdrop-blur-sm" />
            <motion.div initial={{ opacity: 0, scale: 0.9 }} animate={{ opacity: 1, scale: 1 }} exit={{ opacity: 0, scale: 0.9 }} className="relative w-full max-w-md hud-border bg-zinc-950 overflow-hidden flex flex-col">
              <div className="p-6 border-b border-army-gold/20 bg-army-gold/5 flex justify-between items-center">
                <div>
                  <h3 className="text-xl font-black uppercase italic tracking-tighter text-army-gold">Manage_Recruiter</h3>
                  <p className="text-[10px] font-mono text-zinc-500 uppercase tracking-widest">{editingMember.displayName} // {editingMember.email}</p>
                </div>
                <button onClick={() => setEditingMember(null)} className="p-2 hover:bg-army-gold/10 text-zinc-500 hover:text-army-gold"><X className="w-6 h-6" /></button>
              </div>

              <form onSubmit={handleUpdateMember} className="p-6 space-y-4">
                <div>
                  <label className="block text-[10px] font-black uppercase tracking-widest text-zinc-500 mb-2">Role Access</label>
                  <select value={editingMember.role || 'recruiter'} onChange={(e) => setEditingMember({ ...editingMember, role: e.target.value })} className="w-full bg-zinc-900 border border-zinc-800 p-3 text-white font-mono text-sm focus:border-army-gold outline-none">
                    <option value="recruiter">Recruiter (Standard Access)</option>
                    <option value="admin">Admin (Section Chief)</option>
                  </select>
                </div>
                <div>
                  <label className="block text-[10px] font-black uppercase tracking-widest text-zinc-500 mb-2">Platoon Access (Keycards)</label>
                  <div className="flex flex-wrap gap-2">
                    {PLATOONS.map(p => (
                      <label key={p} className="flex items-center gap-2 bg-zinc-900 border border-zinc-800 px-3 py-2 cursor-pointer hover:border-army-gold transition-colors">
                        <input 
                          type="checkbox" 
                          checked={((editingMember as any).platoons || []).includes(p)} 
                          onChange={(e) => {
                            const current = (editingMember as any).platoons || [];
                            const updated = e.target.checked ? [...current, p] : current.filter((x: string) => x !== p);
                            setEditingMember({...editingMember, platoons: updated});
                          }} 
                          className="accent-army-gold"
                        />
                        <span className="text-[10px] text-white font-mono font-black">{p}</span>
                      </label>
                    ))}
                  </div>
                </div>
                <div>
                  <label className="block text-[10px] font-black uppercase tracking-widest text-zinc-500 mb-2">Personal Link Slug</label>
                  <input type="text" value={editingMember.slug || ''} onChange={(e) => setEditingMember({ ...editingMember, slug: e.target.value })} className="w-full bg-zinc-900 border border-zinc-800 p-3 text-white font-mono text-sm focus:border-army-gold outline-none" />
                </div>
                <div className="flex justify-between items-center mt-8 pt-4 border-t border-zinc-800">
                  <button type="button" onClick={() => handleDeleteMember(editingMember.uid, editingMember.email)} className="flex items-center gap-2 text-red-500 hover:bg-red-500/10 px-3 py-2 text-[10px] font-black uppercase tracking-widest transition-colors"><Trash2 className="w-4 h-4"/> Revoke_Access</button>
                  <div className="flex gap-3">
                    <button type="button" onClick={() => setEditingMember(null)} className="px-4 py-2 border border-zinc-800 text-zinc-400 font-black uppercase text-[10px] tracking-widest hover:bg-zinc-800 hover:text-white">Cancel</button>
                    <button type="submit" className="px-4 py-2 bg-army-gold text-army-black font-black uppercase text-[10px] tracking-widest hover:bg-white">Update</button>
                  </div>
                </div>
              </form>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      {/* Profile Settings Modal */}
      <AnimatePresence>
        {showProfileModal && (
          <div className="fixed inset-0 z-[60] flex items-center justify-center p-4">
            <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} onClick={() => setShowProfileModal(false)} className="absolute inset-0 bg-army-black/90 backdrop-blur-sm" />
            <motion.div initial={{ opacity: 0, scale: 0.9, y: 20 }} animate={{ opacity: 1, scale: 1, y: 0 }} exit={{ opacity: 0, scale: 0.9, y: 20 }} className="relative w-full max-w-4xl hud-border bg-zinc-950 overflow-hidden flex flex-col max-h-[90vh]">
              <div className="p-6 border-b border-army-gold/20 bg-army-gold/5 flex justify-between items-center">
                <div>
                  <h3 className="text-xl font-black uppercase italic tracking-tighter text-army-gold">Profile_Settings</h3>
                  <p className="text-[10px] font-mono text-zinc-500 uppercase tracking-widest">Update Public Digital Business Card</p>
                </div>
                <div className="flex items-center gap-4">
                  {userSlug && (
                    <a 
                      href={`https://api.qrserver.com/v1/create-qr-code/?size=500x500&data=${encodeURIComponent(window.location.origin + '/?r=' + userSlug)}`}
                      download={`QR_Code_${userSlug}.png`}
                      target="_blank"
                      rel="noreferrer"
                      className="flex items-center gap-2 px-3 py-1.5 bg-army-gold/10 border border-army-gold/50 text-army-gold text-[10px] font-black uppercase tracking-widest hover:bg-army-gold hover:text-army-black transition-colors"
                    >
                      <QrCode className="w-4 h-4" /> Download_QR
                    </a>
                  )}
                  <button onClick={() => setShowProfileModal(false)} className="p-2 hover:bg-army-gold/10 text-zinc-500 hover:text-army-gold transition-colors">
                    <X className="w-6 h-6" />
                  </button>
                </div>
              </div>

              <div className="overflow-y-auto p-6 scrollbar-hide flex-1">
                <form onSubmit={handleSaveProfile} className="space-y-8">
                  
                  {/* Section 1: Personal Info */}
                  <div>
                    <h4 className="text-[10px] font-black uppercase tracking-widest text-zinc-500 mb-4 border-b border-zinc-800 pb-2">// Personal_Identification</h4>
                    <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                      <div>
                        <label className="flex items-center gap-2 text-[10px] font-black uppercase tracking-widest text-army-gold mb-2">Rank</label>
                        <select value={profileData.rank} onChange={e => setProfileData({...profileData, rank: e.target.value})} className="w-full bg-zinc-900 border border-zinc-800 p-3 text-white font-mono text-sm focus:border-army-gold outline-none">
                          <option value="">Select Rank...</option>
                          <optgroup label="Enlisted">
                            <option value="PVT">PVT (E-1)</option><option value="PV2">PV2 (E-2)</option><option value="PFC">PFC (E-3)</option>
                            <option value="SPC">SPC (E-4)</option><option value="CPL">CPL (E-4)</option><option value="SGT">SGT (E-5)</option>
                            <option value="SSG">SSG (E-6)</option><option value="SFC">SFC (E-7)</option><option value="MSG">MSG (E-8)</option>
                            <option value="1SG">1SG (E-8)</option><option value="SGM">SGM (E-9)</option><option value="CSM">CSM (E-9)</option>
                          </optgroup>
                          <optgroup label="Warrant Officer">
                            <option value="WO1">WO1</option><option value="CW2">CW2</option><option value="CW3">CW3</option>
                            <option value="CW4">CW4</option><option value="CW5">CW5</option>
                          </optgroup>
                          <optgroup label="Officer">
                            <option value="2LT">2LT (O-1)</option><option value="1LT">1LT (O-2)</option><option value="CPT">CPT (O-3)</option>
                            <option value="MAJ">MAJ (O-4)</option><option value="LTC">LTC (O-5)</option><option value="COL">COL (O-6)</option>
                            <option value="BG">BG (O-7)</option><option value="MG">MG (O-8)</option><option value="LTG">LTG (O-9)</option><option value="GEN">GEN (O-10)</option>
                          </optgroup>
                        </select>
                      </div>
                      <div>
                        <label className="flex items-center gap-2 text-[10px] font-black uppercase tracking-widest text-army-gold mb-2">First Name</label>
                        <input type="text" value={profileData.firstName} onChange={e => setProfileData({...profileData, firstName: e.target.value})} className="w-full bg-zinc-900 border border-zinc-800 p-3 text-white font-mono text-sm focus:border-army-gold outline-none" placeholder="e.g. John" />
                      </div>
                      <div>
                        <label className="flex items-center gap-2 text-[10px] font-black uppercase tracking-widest text-army-gold mb-2">Last Name</label>
                        <input type="text" value={profileData.lastName} onChange={e => setProfileData({...profileData, lastName: e.target.value})} className="w-full bg-zinc-900 border border-zinc-800 p-3 text-white font-mono text-sm focus:border-army-gold outline-none" placeholder="e.g. Doe" />
                      </div>
                    </div>
                  </div>

                  {/* Section 2: Contact Methods */}
                  <div>
                    <h4 className="text-[10px] font-black uppercase tracking-widest text-zinc-500 mb-4 border-b border-zinc-800 pb-2">// Comm_Channels</h4>
                    <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
                      <div>
                        <label className="flex items-center gap-2 text-[10px] font-black uppercase tracking-widest text-army-gold mb-2"><Smartphone className="w-3 h-3"/> Cell Phone</label>
                        <input type="tel" value={profileData.cellPhone} onChange={e => setProfileData({...profileData, cellPhone: e.target.value})} className="w-full bg-zinc-900 border border-zinc-800 p-3 text-white font-mono text-sm focus:border-army-gold outline-none" placeholder="561-555-0199" />
                      </div>
                      <div>
                        <label className="flex items-center gap-2 text-[10px] font-black uppercase tracking-widest text-army-gold mb-2"><Phone className="w-3 h-3"/> Office Phone</label>
                        <input type="tel" value={profileData.officePhone} onChange={e => setProfileData({...profileData, officePhone: e.target.value})} className="w-full bg-zinc-900 border border-zinc-800 p-3 text-white font-mono text-sm focus:border-army-gold outline-none" placeholder="561-123-4567" />
                      </div>
                      <div>
                        <label className="flex items-center gap-2 text-[10px] font-black uppercase tracking-widest text-army-gold mb-2">Extension</label>
                        <input type="text" value={profileData.officeExt} onChange={e => setProfileData({...profileData, officeExt: e.target.value})} className="w-full bg-zinc-900 border border-zinc-800 p-3 text-white font-mono text-sm focus:border-army-gold outline-none" placeholder="e.g. 104" />
                      </div>
                      <div>
                        <label className="flex items-center gap-2 text-[10px] font-black uppercase tracking-widest text-army-gold mb-2"><Mail className="w-3 h-3"/> Public Email</label>
                        <input type="email" value={profileData.publicEmail} onChange={e => setProfileData({...profileData, publicEmail: e.target.value})} className="w-full bg-zinc-900 border border-zinc-800 p-3 text-white font-mono text-sm focus:border-army-gold outline-none" placeholder="recruiter@army.mil" />
                      </div>
                    </div>
                  </div>

                  {/* Section 3: Physical Location */}
                  <div>
                    <h4 className="text-[10px] font-black uppercase tracking-widest text-zinc-500 mb-4 border-b border-zinc-800 pb-2">// Physical_Location</h4>
                    <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
                      <div className="md:col-span-2">
                        <label className="flex items-center gap-2 text-[10px] font-black uppercase tracking-widest text-army-gold mb-2"><MapPin className="w-3 h-3"/> Location Type</label>
                        <select value={profileData.locationType} onChange={e => setProfileData({...profileData, locationType: e.target.value})} className="w-full bg-zinc-900 border border-zinc-800 p-3 text-white font-mono text-sm focus:border-army-gold outline-none">
                          <option value="Armory">Armory</option>
                          <option value="College/University">College/University</option>
                          <option value="Store Front">Store Front</option>
                          <option value="HQ">HQ</option>
                        </select>
                      </div>
                      <div className="md:col-span-2">
                        <label className="flex items-center gap-2 text-[10px] font-black uppercase tracking-widest text-army-gold mb-2">Address Line 1</label>
                        <input type="text" value={profileData.address1} onChange={e => setProfileData({...profileData, address1: e.target.value})} className="w-full bg-zinc-900 border border-zinc-800 p-3 text-white font-mono text-sm focus:border-army-gold outline-none" placeholder="777 Glades Rd" />
                      </div>
                      <div className="md:col-span-2">
                        <label className="flex items-center gap-2 text-[10px] font-black uppercase tracking-widest text-army-gold mb-2">Address Line 2 (Apt, Suite, Room)</label>
                        <input type="text" value={profileData.address2} onChange={e => setProfileData({...profileData, address2: e.target.value})} className="w-full bg-zinc-900 border border-zinc-800 p-3 text-white font-mono text-sm focus:border-army-gold outline-none" placeholder="Suite 100" />
                      </div>
                      <div className="md:col-span-2">
                        <label className="flex items-center gap-2 text-[10px] font-black uppercase tracking-widest text-army-gold mb-2">City</label>
                        <input type="text" value={profileData.city} onChange={e => setProfileData({...profileData, city: e.target.value})} className="w-full bg-zinc-900 border border-zinc-800 p-3 text-white font-mono text-sm focus:border-army-gold outline-none" placeholder="Boca Raton" />
                      </div>
                      <div className="md:col-span-2">
                        <label className="flex items-center gap-2 text-[10px] font-black uppercase tracking-widest text-army-gold mb-2">State</label>
                        <input type="text" value={profileData.state} onChange={e => setProfileData({...profileData, state: e.target.value})} className="w-full bg-zinc-900 border border-zinc-800 p-3 text-white font-mono text-sm focus:border-army-gold outline-none" placeholder="FL" />
                      </div>
                      <div className="md:col-span-2">
                        <label className="flex items-center gap-2 text-[10px] font-black uppercase tracking-widest text-army-gold mb-2">ZIP Code</label>
                        <input type="text" value={profileData.zip} onChange={e => setProfileData({...profileData, zip: e.target.value})} className="w-full bg-zinc-900 border border-zinc-800 p-3 text-white font-mono text-sm focus:border-army-gold outline-none" placeholder="33431" />
                      </div>
                    </div>
                  </div>

                  {/* Section 4: Quick Comms Templates */}
                  <div>
                    <h4 className="text-[10px] font-black uppercase tracking-widest text-zinc-500 mb-4 border-b border-zinc-800 pb-2">// Quick_Comms_Templates</h4>
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                      <div>
                        <label className="flex items-center gap-2 text-[10px] font-black uppercase tracking-widest text-army-gold mb-2">SMS Default Message</label>
                        <p className="text-[8px] text-zinc-500 mb-2 font-mono uppercase tracking-widest">Use <span className="text-white">{"{{name}}"}</span> or <span className="text-white">{"{{recruiter}}"}</span> to auto-fill.</p>
                        <textarea 
                          value={profileData.smsTemplate} 
                          onChange={e => setProfileData({...profileData, smsTemplate: e.target.value})} 
                          className="w-full bg-zinc-900 border border-zinc-800 p-3 text-white font-mono text-xs focus:border-army-gold outline-none h-24 resize-none" 
                        />
                      </div>
                      <div>
                        <label className="flex items-center gap-2 text-[10px] font-black uppercase tracking-widest text-army-gold mb-2">Email Default Message</label>
                        <p className="text-[8px] text-zinc-500 mb-2 font-mono uppercase tracking-widest">Use <span className="text-white">{"{{name}}"}</span> or <span className="text-white">{"{{recruiter}}"}</span> to auto-fill.</p>
                        <textarea 
                          value={profileData.emailTemplate} 
                          onChange={e => setProfileData({...profileData, emailTemplate: e.target.value})} 
                          className="w-full bg-zinc-900 border border-zinc-800 p-3 text-white font-mono text-xs focus:border-army-gold outline-none h-24 resize-none" 
                        />
                      </div>
                    </div>
                  </div>

                  {/* Section 5: Social Links */}
                  <div>
                    <h4 className="text-[10px] font-black uppercase tracking-widest text-zinc-500 mb-4 border-b border-zinc-800 pb-2">// Social_Network</h4>
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      
                      <div className="flex">
                        <div className="w-10 bg-zinc-900 border border-r-0 border-zinc-800 flex items-center justify-center text-zinc-500"><Instagram className="w-4 h-4"/></div>
                        <div className="bg-zinc-900 border border-r-0 border-l-0 border-zinc-800 p-3 text-zinc-500 font-mono text-[10px] md:text-xs flex items-center">instagram.com/</div>
                        <input type="text" value={profileData.instagram} onChange={e => setProfileData({...profileData, instagram: e.target.value})} className="flex-1 bg-zinc-900 border border-zinc-800 p-3 text-white font-mono text-sm focus:border-army-gold outline-none" placeholder="username" />
                      </div>

                      <div className="flex">
                        <div className="w-10 bg-zinc-900 border border-r-0 border-zinc-800 flex items-center justify-center text-zinc-500"><Facebook className="w-4 h-4"/></div>
                        <div className="bg-zinc-900 border border-r-0 border-l-0 border-zinc-800 p-3 text-zinc-500 font-mono text-[10px] md:text-xs flex items-center">facebook.com/</div>
                        <input type="text" value={profileData.facebook} onChange={e => setProfileData({...profileData, facebook: e.target.value})} className="flex-1 bg-zinc-900 border border-zinc-800 p-3 text-white font-mono text-sm focus:border-army-gold outline-none" placeholder="username" />
                      </div>

                      <div className="flex">
                        <div className="w-10 bg-zinc-900 border border-r-0 border-zinc-800 flex items-center justify-center text-zinc-500"><svg className="w-4 h-4 fill-current" viewBox="0 0 24 24"><path d="M19.59 6.69a4.83 4.83 0 0 1-3.77-4.25V2h-3.45v13.67a2.89 2.89 0 0 1-5.2 1.74 2.89 2.89 0 0 1 2.31-4.64 2.93 2.93 0 0 1 .88.13V9.4a6.84 6.84 0 0 0-1-.05A6.33 6.33 0 0 0 5 20.1a6.34 6.34 0 0 0 10.86-4.43v-7a8.16 8.16 0 0 0 4.77 1.52v-3.4a4.85 4.85 0 0 1-1-.1z"/></svg></div>
                        <div className="bg-zinc-900 border border-r-0 border-l-0 border-zinc-800 p-3 text-zinc-500 font-mono text-[10px] md:text-xs flex items-center">tiktok.com/@</div>
                        <input type="text" value={profileData.tiktok} onChange={e => setProfileData({...profileData, tiktok: e.target.value})} className="flex-1 bg-zinc-900 border border-zinc-800 p-3 text-white font-mono text-sm focus:border-army-gold outline-none" placeholder="username" />
                      </div>

                      <div className="flex">
                        <div className="w-10 bg-zinc-900 border border-r-0 border-zinc-800 flex items-center justify-center text-zinc-500"><Linkedin className="w-4 h-4"/></div>
                        <div className="bg-zinc-900 border border-r-0 border-l-0 border-zinc-800 p-3 text-zinc-500 font-mono text-[10px] md:text-xs flex items-center">linkedin.com/in/</div>
                        <input type="text" value={profileData.linkedin} onChange={e => setProfileData({...profileData, linkedin: e.target.value})} className="flex-1 bg-zinc-900 border border-zinc-800 p-3 text-white font-mono text-sm focus:border-army-gold outline-none" placeholder="username" />
                      </div>

                      <div className="flex">
                        <div className="w-10 bg-zinc-900 border border-r-0 border-zinc-800 flex items-center justify-center text-zinc-500"><Youtube className="w-4 h-4"/></div>
                        <div className="bg-zinc-900 border border-r-0 border-l-0 border-zinc-800 p-3 text-zinc-500 font-mono text-[10px] md:text-xs flex items-center">youtube.com/@</div>
                        <input type="text" value={profileData.youtube} onChange={e => setProfileData({...profileData, youtube: e.target.value})} className="flex-1 bg-zinc-900 border border-zinc-800 p-3 text-white font-mono text-sm focus:border-army-gold outline-none" placeholder="channelname" />
                      </div>

                      <div className="flex">
                        <div className="w-10 bg-zinc-900 border border-r-0 border-zinc-800 flex items-center justify-center text-zinc-500"><MessageSquare className="w-4 h-4"/></div>
                        <div className="bg-zinc-900 border border-r-0 border-l-0 border-zinc-800 p-3 text-zinc-500 font-mono text-[10px] md:text-xs flex items-center">discord.gg/</div>
                        <input type="text" value={profileData.discord} onChange={e => setProfileData({...profileData, discord: e.target.value})} className="flex-1 bg-zinc-900 border border-zinc-800 p-3 text-white font-mono text-sm focus:border-army-gold outline-none" placeholder="invite-code" />
                      </div>

                      <div className="flex md:col-span-2">
                        <div className="w-10 bg-zinc-900 border border-r-0 border-zinc-800 flex items-center justify-center text-zinc-500"><LinkIcon className="w-4 h-4"/></div>
                        <div className="bg-zinc-900 border border-r-0 border-l-0 border-zinc-800 p-3 text-zinc-500 font-mono text-[10px] md:text-xs flex items-center">linktr.ee/</div>
                        <input type="text" value={profileData.linktree} onChange={e => setProfileData({...profileData, linktree: e.target.value})} className="flex-1 bg-zinc-900 border border-zinc-800 p-3 text-white font-mono text-sm focus:border-army-gold outline-none" placeholder="username" />
                      </div>

                    </div>
                  </div>
                  
                  <div className="pt-6 flex justify-end gap-4 border-t border-zinc-800">
                    <button type="button" onClick={() => setShowProfileModal(false)} className="px-6 py-3 border border-zinc-800 text-zinc-400 font-black uppercase tracking-widest hover:bg-zinc-800 hover:text-white transition-colors">Cancel</button>
                    <button type="submit" className="px-6 py-3 bg-army-gold text-army-black font-black uppercase tracking-widest hover:bg-white transition-colors">Save_Profile</button>
                  </div>
                </form>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      {/* Create Recruiter Modal */}
      <AnimatePresence>
        {showCreateRecruiter && (
          <div className="fixed inset-0 z-[60] flex items-center justify-center p-4 md:p-6">
            <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} onClick={() => setShowCreateRecruiter(false)} className="absolute inset-0 bg-army-black/90 backdrop-blur-sm" />
            <motion.div initial={{ opacity: 0, scale: 0.9, y: 20 }} animate={{ opacity: 1, scale: 1, y: 0 }} exit={{ opacity: 0, scale: 0.9, y: 20 }} className="relative w-full max-w-md hud-border bg-zinc-950 overflow-hidden flex flex-col">
              <div className="p-6 border-b border-army-gold/20 bg-army-gold/5 flex justify-between items-center">
                <div>
                  <h3 className="text-xl font-black uppercase italic tracking-tighter text-army-gold">Create_Recruiter</h3>
                  <p className="text-[10px] font-mono text-zinc-500 uppercase tracking-widest">Add_New_Team_Member</p>
                </div>
                <button onClick={() => setShowCreateRecruiter(false)} className="p-2 hover:bg-army-gold/10 text-zinc-500 hover:text-army-gold transition-colors"><X className="w-6 h-6" /></button>
              </div>
              <div className="p-6">
                <form onSubmit={handleCreateRecruiter} className="space-y-4">
                  <div>
                    <label className="block text-[10px] font-black uppercase tracking-widest text-zinc-500 mb-2">Email_Address</label>
                    <input type="email" required value={createRecruiterEmail} onChange={(e) => setCreateRecruiterEmail(e.target.value)} className="w-full bg-zinc-900 border border-zinc-800 p-3 text-white font-mono text-sm focus:border-army-gold outline-none transition-colors" placeholder="recruiter@example.com" />
                  </div>
                  <div>
                    <label className="block text-[10px] font-black uppercase tracking-widest text-zinc-500 mb-2">Display_Name</label>
                    <input type="text" required value={createRecruiterName} onChange={(e) => setCreateRecruiterName(e.target.value)} className="w-full bg-zinc-900 border border-zinc-800 p-3 text-white font-mono text-sm focus:border-army-gold outline-none transition-colors" placeholder="SGT Smith" />
                  </div>
                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <label className="block text-[10px] font-black uppercase tracking-widest text-zinc-500 mb-2">Role</label>
                      <select value={createRecruiterRole} onChange={(e) => setCreateRecruiterRole(e.target.value)} className="w-full bg-zinc-900 border border-zinc-800 p-3 text-white font-mono text-sm focus:border-army-gold outline-none transition-colors">
                        <option value="recruiter">Recruiter</option>
                        <option value="admin">Admin (Section Chief)</option>
                      </select>
                    </div>
                    <div>
                      <label className="block text-[10px] font-black uppercase tracking-widest text-zinc-500 mb-2">Platoon</label>
                      <select value={createRecruiterPlatoon} onChange={(e) => setCreateRecruiterPlatoon(e.target.value)} className="w-full bg-zinc-900 border border-zinc-800 p-3 text-white font-mono text-sm focus:border-army-gold outline-none transition-colors">
                        {PLATOONS.map(p => <option key={p} value={p}>{p}</option>)}
                      </select>
                    </div>
                  </div>
                  <div>
                    <label className="block text-[10px] font-black uppercase tracking-widest text-zinc-500 mb-2">Personal_Link_Slug</label>
                    <input type="text" required value={createRecruiterSlug} onChange={(e) => setCreateRecruiterSlug(e.target.value)} className="w-full bg-zinc-900 border border-zinc-800 p-3 text-white font-mono text-sm focus:border-army-gold outline-none transition-colors" placeholder="sgt-smith" />
                    <p className="text-[10px] text-zinc-500 mt-1 font-mono">Link will be: ?r={createRecruiterSlug || 'slug'}</p>
                  </div>
                  <div className="pt-4 flex justify-end gap-3 border-t border-zinc-800 mt-6">
                    <button type="button" onClick={() => setShowCreateRecruiter(false)} className="px-6 py-3 border border-zinc-800 text-zinc-500 font-black uppercase tracking-widest hover:bg-zinc-900 hover:text-white transition-colors">Cancel</button>
                    <button type="submit" className="px-6 py-3 bg-army-gold/10 border border-army-gold/50 text-army-gold font-black uppercase tracking-widest hover:bg-army-gold hover:text-army-black transition-colors">Pre-Approve</button>
                  </div>
                </form>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>
    </div>
  );
};